package org.andromda.cartridges.jsf.tests.constraints.actions.triggerpresent;

/**
 * Provides the ability to populate any view in the TriggerPresent UseCase
 */
public final class TriggerPresentUseCaseViewPopulator
{
}