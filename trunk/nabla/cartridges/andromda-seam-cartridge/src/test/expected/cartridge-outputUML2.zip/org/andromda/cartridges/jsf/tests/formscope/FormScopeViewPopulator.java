package org.andromda.cartridges.jsf.tests.formscope;

import java.util.Map;

/**
 * Provides the ability to populate any view in the FormScope
 */
public final class FormScopeViewPopulator
{
    public static void populateForm(APageSubmitFormImpl fromForm, APageSubmitFormImpl toForm)
    {
        toForm.setEventParam(fromForm.getEventParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(FormScopeFormImpl fromForm, APageSubmitFormImpl toForm)
    {
        toForm.setEventParam(fromForm.getEventParam());
        toForm.resetIsSetFlags();
    }

    public static void populateAPagePageVariables(Object fromForm, Map<String,Object> pageVariables)
    {
        if(fromForm instanceof FormScopeFormImpl)
        {
            final FormScopeFormImpl sourceForm=(FormScopeFormImpl)fromForm;
            if(sourceForm.isPageVarSet())
            {
                pageVariables.put("pageVar",sourceForm.getPageVar());
            }
        }
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, APageSubmitFormImpl toForm)
    {
        if(fromForm instanceof APageSubmitFormImpl)
        {
            populateForm((APageSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof FormScopeFormImpl)
        {
            populateForm((FormScopeFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}