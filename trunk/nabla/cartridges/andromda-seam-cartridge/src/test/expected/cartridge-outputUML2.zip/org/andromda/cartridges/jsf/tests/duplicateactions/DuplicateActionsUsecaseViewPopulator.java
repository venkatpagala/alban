package org.andromda.cartridges.jsf.tests.duplicateactions;

/**
 * Provides the ability to populate any view in the DuplicateActions usecase
 */
public final class DuplicateActionsUsecaseViewPopulator
{
    public static void populateForm(ShowSomethingSendFormImpl fromForm, ShowSomethingSendFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingSubmitFormImpl fromForm, ShowSomethingSendFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingSubmitFormImpl fromForm, ShowSomethingSendFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(DuplicateActionsUsecaseFormImpl fromForm, ShowSomethingSendFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingSendFormImpl fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingSubmitFormImpl fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingSubmitFormImpl fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(DuplicateActionsUsecaseFormImpl fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingSendFormImpl fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingSubmitFormImpl fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingSubmitFormImpl fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(DuplicateActionsUsecaseFormImpl fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, ShowSomethingSendFormImpl toForm)
    {
        if(fromForm instanceof ShowSomethingSendFormImpl)
        {
            populateForm((ShowSomethingSendFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ShowSomethingSubmitFormImpl)
        {
            populateForm((ShowSomethingSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ShowSomethingSubmitFormImpl)
        {
            populateForm((ShowSomethingSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof DuplicateActionsUsecaseFormImpl)
        {
            populateForm((DuplicateActionsUsecaseFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        if(fromForm instanceof ShowSomethingSendFormImpl)
        {
            populateForm((ShowSomethingSendFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ShowSomethingSubmitFormImpl)
        {
            populateForm((ShowSomethingSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ShowSomethingSubmitFormImpl)
        {
            populateForm((ShowSomethingSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof DuplicateActionsUsecaseFormImpl)
        {
            populateForm((DuplicateActionsUsecaseFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        if(fromForm instanceof ShowSomethingSendFormImpl)
        {
            populateForm((ShowSomethingSendFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ShowSomethingSubmitFormImpl)
        {
            populateForm((ShowSomethingSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ShowSomethingSubmitFormImpl)
        {
            populateForm((ShowSomethingSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof DuplicateActionsUsecaseFormImpl)
        {
            populateForm((DuplicateActionsUsecaseFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}