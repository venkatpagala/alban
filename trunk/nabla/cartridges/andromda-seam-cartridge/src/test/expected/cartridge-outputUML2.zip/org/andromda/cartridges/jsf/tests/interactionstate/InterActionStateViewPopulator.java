package org.andromda.cartridges.jsf.tests.interactionstate;

/**
 * Provides the ability to populate any view in the InterActionState
 */
public final class InterActionStateViewPopulator
{
    public static void populateForm(Page1SubmitFormImpl fromForm, Page1SubmitFormImpl toForm)
    {
        toForm.setInterActionStateParam(fromForm.getInterActionStateParam());
        toForm.setParam(fromForm.getParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(InterActionStateFormImpl fromForm, Page1SubmitFormImpl toForm)
    {
        toForm.setParam(fromForm.getParam());
        toForm.resetIsSetFlags();
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, Page1SubmitFormImpl toForm)
    {
        if(fromForm instanceof Page1SubmitFormImpl)
        {
            populateForm((Page1SubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof InterActionStateFormImpl)
        {
            populateForm((InterActionStateFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}