package org.andromda.cartridges.jsf.tests.controllertv;

/**
 * Provides the ability to populate any view in the ControllerTV
 */
public final class ControllerTVViewPopulator
{
}