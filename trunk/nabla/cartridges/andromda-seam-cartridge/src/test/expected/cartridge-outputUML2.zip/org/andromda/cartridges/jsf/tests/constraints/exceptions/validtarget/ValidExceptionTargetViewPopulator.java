package org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget;

/**
 * Provides the ability to populate any view in the ValidExceptionTarget
 */
public final class ValidExceptionTargetViewPopulator
{
}