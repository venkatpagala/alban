package org.andromda.cartridges.jsf.tests.graphoutusecase.usecase;

/**
 * Provides the ability to populate any view in the GraphOutUseCase
 */
public final class GraphOutUseCaseViewPopulator
{
}