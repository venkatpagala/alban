package org.andromda.cartridges.jsf.tests.formfields;

/**
 * Provides the ability to populate any view in the FormFields
 */
public final class FormFieldsViewPopulator
{
    public static void populateForm(OneSubmitFormImpl fromForm, OneSubmitFormImpl toForm)
    {
        toForm.setDate(fromForm.getDate());
        toForm.setTime(fromForm.getTime());
        toForm.setText(fromForm.getText());
        toForm.setNumber(fromForm.getNumber());
        toForm.setCollections(fromForm.getCollections());
        toForm.setSelectable(fromForm.getSelectable());
        toForm.setSelectableValueList(fromForm.getSelectableValueList());
        toForm.setSelectableLabelList(fromForm.getSelectableLabelList());
        toForm.setBool(fromForm.isBool());
        toForm.setMultiSelects(fromForm.getMultiSelects());
        toForm.setMultiSelectsValueList(fromForm.getMultiSelectsValueList());
        toForm.setMultiSelectsLabelList(fromForm.getMultiSelectsLabelList());
        toForm.setTitle(fromForm.getTitle());
        toForm.setFile(fromForm.getFile());
        toForm.setMultiFormat(fromForm.getMultiFormat());
        toForm.setDateWithTime(fromForm.getDateWithTime());
        toForm.setDateWithoutCalendar(fromForm.getDateWithoutCalendar());
        toForm.setHasCustomValidator(fromForm.getHasCustomValidator());
        toForm.setIntegerClass(fromForm.getIntegerClass());
        toForm.setSetClasses(fromForm.getSetClasses());
        toForm.setMapClass(fromForm.getMapClass());
        toForm.setBooleanClass(fromForm.getBooleanClass());
        toForm.setFloatClass(fromForm.getFloatClass());
        toForm.setHiddenWithDefaultValue(fromForm.getHiddenWithDefaultValue());
        toForm.setBAdName(fromForm.getBAdName());
        toForm.setComplexParameter(fromForm.getComplexParameter());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ThreeGoFormImpl fromForm, OneSubmitFormImpl toForm)
    {
        toForm.setDate(fromForm.getDate());
        toForm.setTime(fromForm.getTime());
        toForm.setText(fromForm.getText());
        toForm.setNumber(fromForm.getNumber());
        toForm.setCollections(fromForm.getCollections());
        toForm.setSelectable(fromForm.getSelectable());
        toForm.setSelectableValueList(fromForm.getSelectableValueList());
        toForm.setSelectableLabelList(fromForm.getSelectableLabelList());
        toForm.setBool(fromForm.isBool());
        toForm.setMultiSelects(fromForm.getMultiSelects());
        toForm.setMultiSelectsValueList(fromForm.getMultiSelectsValueList());
        toForm.setMultiSelectsLabelList(fromForm.getMultiSelectsLabelList());
        toForm.setTitle(fromForm.getTitle());
        toForm.setFile(fromForm.getFile());
        toForm.setMultiFormat(fromForm.getMultiFormat());
        toForm.setDateWithTime(fromForm.getDateWithTime());
        toForm.setDateWithoutCalendar(fromForm.getDateWithoutCalendar());
        toForm.setHasCustomValidator(fromForm.getHasCustomValidator());
        toForm.setIntegerClass(fromForm.getIntegerClass());
        toForm.setSetClasses(fromForm.getSetClasses());
        toForm.setMapClass(fromForm.getMapClass());
        toForm.setBooleanClass(fromForm.getBooleanClass());
        toForm.setFloatClass(fromForm.getFloatClass());
        toForm.setHiddenWithDefaultValue(fromForm.getHiddenWithDefaultValue());
        toForm.setBAdName(fromForm.getBAdName());
        toForm.setComplexParameter(fromForm.getComplexParameter());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(FormFieldsFormImpl fromForm, OneSubmitFormImpl toForm)
    {
        toForm.setDate(fromForm.getDate());
        toForm.setTime(fromForm.getTime());
        toForm.setText(fromForm.getText());
        toForm.setNumber(fromForm.getNumber());
        toForm.setCollections(fromForm.getCollections());
        toForm.setSelectable(fromForm.getSelectable());
        toForm.setSelectableValueList(fromForm.getSelectableValueList());
        toForm.setSelectableLabelList(fromForm.getSelectableLabelList());
        toForm.setBool(fromForm.isBool());
        toForm.setMultiSelects(fromForm.getMultiSelects());
        toForm.setMultiSelectsValueList(fromForm.getMultiSelectsValueList());
        toForm.setMultiSelectsLabelList(fromForm.getMultiSelectsLabelList());
        toForm.setTitle(fromForm.getTitle());
        toForm.setFile(fromForm.getFile());
        toForm.setMultiFormat(fromForm.getMultiFormat());
        toForm.setDateWithTime(fromForm.getDateWithTime());
        toForm.setDateWithoutCalendar(fromForm.getDateWithoutCalendar());
        toForm.setHasCustomValidator(fromForm.getHasCustomValidator());
        toForm.setIntegerClass(fromForm.getIntegerClass());
        toForm.setSetClasses(fromForm.getSetClasses());
        toForm.setMapClass(fromForm.getMapClass());
        toForm.setBooleanClass(fromForm.getBooleanClass());
        toForm.setFloatClass(fromForm.getFloatClass());
        toForm.setHiddenWithDefaultValue(fromForm.getHiddenWithDefaultValue());
        toForm.setBAdName(fromForm.getBAdName());
        toForm.setComplexParameter(fromForm.getComplexParameter());
        toForm.resetIsSetFlags();
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, OneSubmitFormImpl toForm)
    {
        if(fromForm instanceof OneSubmitFormImpl)
        {
            populateForm((OneSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ThreeGoFormImpl)
        {
            populateForm((ThreeGoFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof FormFieldsFormImpl)
        {
            populateForm((FormFieldsFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
    public static void populateForm(OneSubmitFormImpl fromForm, ThreeGoFormImpl toForm)
    {
        toForm.setDate(fromForm.getDate());
        toForm.setTime(fromForm.getTime());
        toForm.setText(fromForm.getText());
        toForm.setNumber(fromForm.getNumber());
        toForm.setCollections(fromForm.getCollections());
        toForm.setSelectable(fromForm.getSelectable());
        toForm.setSelectableValueList(fromForm.getSelectableValueList());
        toForm.setSelectableLabelList(fromForm.getSelectableLabelList());
        toForm.setBool(fromForm.isBool());
        toForm.setMultiSelects(fromForm.getMultiSelects());
        toForm.setMultiSelectsValueList(fromForm.getMultiSelectsValueList());
        toForm.setMultiSelectsLabelList(fromForm.getMultiSelectsLabelList());
        toForm.setTitle(fromForm.getTitle());
        toForm.setFile(fromForm.getFile());
        toForm.setMultiFormat(fromForm.getMultiFormat());
        toForm.setDateWithTime(fromForm.getDateWithTime());
        toForm.setDateWithoutCalendar(fromForm.getDateWithoutCalendar());
        toForm.setHasCustomValidator(fromForm.getHasCustomValidator());
        toForm.setIntegerClass(fromForm.getIntegerClass());
        toForm.setSetClasses(fromForm.getSetClasses());
        toForm.setMapClass(fromForm.getMapClass());
        toForm.setBooleanClass(fromForm.getBooleanClass());
        toForm.setFloatClass(fromForm.getFloatClass());
        toForm.setHiddenWithDefaultValue(fromForm.getHiddenWithDefaultValue());
        toForm.setBAdName(fromForm.getBAdName());
        toForm.setComplexParameter(fromForm.getComplexParameter());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ThreeGoFormImpl fromForm, ThreeGoFormImpl toForm)
    {
        toForm.setDate(fromForm.getDate());
        toForm.setTime(fromForm.getTime());
        toForm.setText(fromForm.getText());
        toForm.setNumber(fromForm.getNumber());
        toForm.setCollections(fromForm.getCollections());
        toForm.setSelectable(fromForm.getSelectable());
        toForm.setSelectableValueList(fromForm.getSelectableValueList());
        toForm.setSelectableLabelList(fromForm.getSelectableLabelList());
        toForm.setBool(fromForm.isBool());
        toForm.setMultiSelects(fromForm.getMultiSelects());
        toForm.setMultiSelectsValueList(fromForm.getMultiSelectsValueList());
        toForm.setMultiSelectsLabelList(fromForm.getMultiSelectsLabelList());
        toForm.setTitle(fromForm.getTitle());
        toForm.setFile(fromForm.getFile());
        toForm.setMultiFormat(fromForm.getMultiFormat());
        toForm.setDateWithTime(fromForm.getDateWithTime());
        toForm.setDateWithoutCalendar(fromForm.getDateWithoutCalendar());
        toForm.setHasCustomValidator(fromForm.getHasCustomValidator());
        toForm.setIntegerClass(fromForm.getIntegerClass());
        toForm.setSetClasses(fromForm.getSetClasses());
        toForm.setMapClass(fromForm.getMapClass());
        toForm.setBooleanClass(fromForm.getBooleanClass());
        toForm.setFloatClass(fromForm.getFloatClass());
        toForm.setHiddenWithDefaultValue(fromForm.getHiddenWithDefaultValue());
        toForm.setBAdName(fromForm.getBAdName());
        toForm.setComplexParameter(fromForm.getComplexParameter());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(FormFieldsFormImpl fromForm, ThreeGoFormImpl toForm)
    {
        toForm.setDate(fromForm.getDate());
        toForm.setTime(fromForm.getTime());
        toForm.setText(fromForm.getText());
        toForm.setNumber(fromForm.getNumber());
        toForm.setCollections(fromForm.getCollections());
        toForm.setSelectable(fromForm.getSelectable());
        toForm.setSelectableValueList(fromForm.getSelectableValueList());
        toForm.setSelectableLabelList(fromForm.getSelectableLabelList());
        toForm.setBool(fromForm.isBool());
        toForm.setMultiSelects(fromForm.getMultiSelects());
        toForm.setMultiSelectsValueList(fromForm.getMultiSelectsValueList());
        toForm.setMultiSelectsLabelList(fromForm.getMultiSelectsLabelList());
        toForm.setTitle(fromForm.getTitle());
        toForm.setFile(fromForm.getFile());
        toForm.setMultiFormat(fromForm.getMultiFormat());
        toForm.setDateWithTime(fromForm.getDateWithTime());
        toForm.setDateWithoutCalendar(fromForm.getDateWithoutCalendar());
        toForm.setHasCustomValidator(fromForm.getHasCustomValidator());
        toForm.setIntegerClass(fromForm.getIntegerClass());
        toForm.setSetClasses(fromForm.getSetClasses());
        toForm.setMapClass(fromForm.getMapClass());
        toForm.setBooleanClass(fromForm.getBooleanClass());
        toForm.setFloatClass(fromForm.getFloatClass());
        toForm.setHiddenWithDefaultValue(fromForm.getHiddenWithDefaultValue());
        toForm.setBAdName(fromForm.getBAdName());
        toForm.setComplexParameter(fromForm.getComplexParameter());
        toForm.resetIsSetFlags();
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, ThreeGoFormImpl toForm)
    {
        if(fromForm instanceof OneSubmitFormImpl)
        {
            populateForm((OneSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ThreeGoFormImpl)
        {
            populateForm((ThreeGoFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof FormFieldsFormImpl)
        {
            populateForm((FormFieldsFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}