package org.andromda.cartridges.jsf.tests.messages;

/**
 * Provides the ability to populate any view in the Messages Activity
 */
public final class MessagesActivityViewPopulator
{
}