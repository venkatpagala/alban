package org.andromda.cartridges.jsf.tests.services;

/**
 * Provides the ability to populate any view in the Services
 */
public final class ServicesViewPopulator
{
}