package org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames;

/**
 * Provides the ability to populate any view in the duplicate operation names
 */
public final class DuplicateOperationNamesViewPopulator
{
}