package org.andromda.cartridges.jsf.tests.widgets;

/**
 * Provides the ability to populate any view in the Widgets Activity
 */
public final class WidgetsActivityViewPopulator
{
    public static void populateForm(ShowWidgetsSubmitFormImpl fromForm, ShowWidgetsSubmitFormImpl toForm)
    {
        toForm.setTextFieldTest(fromForm.getTextFieldTest());
        toForm.setPasswordFieldTest(fromForm.getPasswordFieldTest());
        toForm.setTextAreaTest(fromForm.getTextAreaTest());
        toForm.setCheckboxTest(fromForm.isCheckboxTest());
        toForm.setRadioButtonsTest(fromForm.getRadioButtonsTest());
        toForm.setRadioButtonsTestValueList(fromForm.getRadioButtonsTestValueList());
        toForm.setRadioButtonsTestLabelList(fromForm.getRadioButtonsTestLabelList());
        toForm.setRadioButtonsTest2(fromForm.getRadioButtonsTest2());
        toForm.setRadioButtonsTest2ValueList(fromForm.getRadioButtonsTest2ValueList());
        toForm.setRadioButtonsTest2LabelList(fromForm.getRadioButtonsTest2LabelList());
        toForm.setRadioButtonsTest3(fromForm.getRadioButtonsTest3());
        toForm.setRadioButtonsTest3ValueList(fromForm.getRadioButtonsTest3ValueList());
        toForm.setRadioButtonsTest3LabelList(fromForm.getRadioButtonsTest3LabelList());
        toForm.setSelectTest(fromForm.getSelectTest());
        toForm.setSelectTestValueList(fromForm.getSelectTestValueList());
        toForm.setSelectTestLabelList(fromForm.getSelectTestLabelList());
        toForm.setHiddenTest(fromForm.getHiddenTest());
        toForm.setTextFieldTest2(fromForm.getTextFieldTest2());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(WidgetsActivityFormImpl fromForm, ShowWidgetsSubmitFormImpl toForm)
    {
        toForm.setTextFieldTest(fromForm.getTextFieldTest());
        toForm.setPasswordFieldTest(fromForm.getPasswordFieldTest());
        toForm.setTextAreaTest(fromForm.getTextAreaTest());
        toForm.setCheckboxTest(fromForm.isCheckboxTest());
        toForm.setRadioButtonsTest(fromForm.getRadioButtonsTest());
        toForm.setRadioButtonsTestValueList(fromForm.getRadioButtonsTestValueList());
        toForm.setRadioButtonsTestLabelList(fromForm.getRadioButtonsTestLabelList());
        toForm.setRadioButtonsTest2(fromForm.getRadioButtonsTest2());
        toForm.setRadioButtonsTest2ValueList(fromForm.getRadioButtonsTest2ValueList());
        toForm.setRadioButtonsTest2LabelList(fromForm.getRadioButtonsTest2LabelList());
        toForm.setRadioButtonsTest3(fromForm.getRadioButtonsTest3());
        toForm.setRadioButtonsTest3ValueList(fromForm.getRadioButtonsTest3ValueList());
        toForm.setRadioButtonsTest3LabelList(fromForm.getRadioButtonsTest3LabelList());
        toForm.setSelectTest(fromForm.getSelectTest());
        toForm.setSelectTestValueList(fromForm.getSelectTestValueList());
        toForm.setSelectTestLabelList(fromForm.getSelectTestLabelList());
        toForm.setHiddenTest(fromForm.getHiddenTest());
        toForm.setTextFieldTest2(fromForm.getTextFieldTest2());
        toForm.resetIsSetFlags();
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, ShowWidgetsSubmitFormImpl toForm)
    {
        if(fromForm instanceof ShowWidgetsSubmitFormImpl)
        {
            populateForm((ShowWidgetsSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof WidgetsActivityFormImpl)
        {
            populateForm((WidgetsActivityFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}