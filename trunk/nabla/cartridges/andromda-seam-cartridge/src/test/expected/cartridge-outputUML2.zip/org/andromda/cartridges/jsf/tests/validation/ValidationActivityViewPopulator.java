package org.andromda.cartridges.jsf.tests.validation;

/**
 * Provides the ability to populate any view in the Validation Activity
 */
public final class ValidationActivityViewPopulator
{
    public static void populateForm(EnterDataValidateFormImpl fromForm, EnterDataValidateFormImpl toForm)
    {
        toForm.setMinlengthTest(fromForm.getMinlengthTest());
        toForm.setMaxlengthTest(fromForm.getMaxlengthTest());
        toForm.setPatternTest(fromForm.getPatternTest());
        toForm.setCreditcardTest(fromForm.getCreditcardTest());
        toForm.setEmailTest(fromForm.getEmailTest());
        toForm.setUrlTest(fromForm.getUrlTest());
        toForm.setIntRangeTest(fromForm.getIntRangeTest());
        toForm.setFloatRangeTest(fromForm.getFloatRangeTest());
        toForm.setDoubleRangeTest(fromForm.getDoubleRangeTest());
        toForm.setIntWrapperRangeTest(fromForm.getIntWrapperRangeTest());
        toForm.setFloatWrapperRangeTest(fromForm.getFloatWrapperRangeTest());
        toForm.setDoubleWrapperRangeTest(fromForm.getDoubleWrapperRangeTest());
        toForm.setLenientDateTest(fromForm.getLenientDateTest());
        toForm.setStrictDateTest(fromForm.getStrictDateTest());
        toForm.setRequiredTest(fromForm.getRequiredTest());
        toForm.setHiddenNotValidated(fromForm.getHiddenNotValidated());
        toForm.setMinLengthOnPasswordTest(fromForm.getMinLengthOnPasswordTest());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ValidationActivityFormImpl fromForm, EnterDataValidateFormImpl toForm)
    {
        toForm.setMinlengthTest(fromForm.getMinlengthTest());
        toForm.setMaxlengthTest(fromForm.getMaxlengthTest());
        toForm.setPatternTest(fromForm.getPatternTest());
        toForm.setCreditcardTest(fromForm.getCreditcardTest());
        toForm.setEmailTest(fromForm.getEmailTest());
        toForm.setUrlTest(fromForm.getUrlTest());
        toForm.setIntRangeTest(fromForm.getIntRangeTest());
        toForm.setFloatRangeTest(fromForm.getFloatRangeTest());
        toForm.setDoubleRangeTest(fromForm.getDoubleRangeTest());
        toForm.setIntWrapperRangeTest(fromForm.getIntWrapperRangeTest());
        toForm.setFloatWrapperRangeTest(fromForm.getFloatWrapperRangeTest());
        toForm.setDoubleWrapperRangeTest(fromForm.getDoubleWrapperRangeTest());
        toForm.setLenientDateTest(fromForm.getLenientDateTest());
        toForm.setStrictDateTest(fromForm.getStrictDateTest());
        toForm.setRequiredTest(fromForm.getRequiredTest());
        toForm.setHiddenNotValidated(fromForm.getHiddenNotValidated());
        toForm.setMinLengthOnPasswordTest(fromForm.getMinLengthOnPasswordTest());
        toForm.resetIsSetFlags();
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, EnterDataValidateFormImpl toForm)
    {
        if(fromForm instanceof EnterDataValidateFormImpl)
        {
            populateForm((EnterDataValidateFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ValidationActivityFormImpl)
        {
            populateForm((ValidationActivityFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}