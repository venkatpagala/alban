package org.andromda.cartridges.jsf.tests.reset;

/**
 * Provides the ability to populate any view in the Reset
 */
public final class ResetViewPopulator
{
    public static void populateForm(ResetPageSendWithResetFormImpl fromForm, ResetPageSendWithResetFormImpl toForm)
    {
        toForm.setFirstParam(fromForm.getFirstParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ResetFormImpl fromForm, ResetPageSendWithResetFormImpl toForm)
    {
        toForm.setFirstParam(fromForm.getFirstParam());
        toForm.resetIsSetFlags();
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, ResetPageSendWithResetFormImpl toForm)
    {
        if(fromForm instanceof ResetPageSendWithResetFormImpl)
        {
            populateForm((ResetPageSendWithResetFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ResetFormImpl)
        {
            populateForm((ResetFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}