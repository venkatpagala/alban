package org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase;

/**
 * Provides the ability to populate any view in the OperationNameAsUseCase
 */
public final class OperationNameAsUseCaseViewPopulator
{
}