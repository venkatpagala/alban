package org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget;

/**
 * Provides the ability to populate any view in the DecisionsBadTarget
 */
public final class DecisionsBadTargetViewPopulator
{
}