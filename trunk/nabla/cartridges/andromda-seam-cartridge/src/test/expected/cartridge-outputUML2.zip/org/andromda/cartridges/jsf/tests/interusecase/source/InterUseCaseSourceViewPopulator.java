package org.andromda.cartridges.jsf.tests.interusecase.source;

/**
 * Provides the ability to populate any view in the InterUseCaseSource
 */
public final class InterUseCaseSourceViewPopulator
{
    public static void populateForm(SourceSubmitFormImpl fromForm, SourceSubmitFormImpl toForm)
    {
        toForm.setSourceParam1(fromForm.getSourceParam1());
        toForm.setSourceParam2(fromForm.getSourceParam2());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(InterUseCaseSourceFormImpl fromForm, SourceSubmitFormImpl toForm)
    {
        toForm.setSourceParam1(fromForm.getSourceParam1());
        toForm.setSourceParam2(fromForm.getSourceParam2());
        toForm.resetIsSetFlags();
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, SourceSubmitFormImpl toForm)
    {
        if(fromForm instanceof SourceSubmitFormImpl)
        {
            populateForm((SourceSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof InterUseCaseSourceFormImpl)
        {
            populateForm((InterUseCaseSourceFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}