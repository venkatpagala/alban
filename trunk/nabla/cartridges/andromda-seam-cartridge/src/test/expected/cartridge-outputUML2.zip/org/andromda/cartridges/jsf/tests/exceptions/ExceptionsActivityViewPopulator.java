package org.andromda.cartridges.jsf.tests.exceptions;

/**
 * Provides the ability to populate any view in the Exceptions Activity
 */
public final class ExceptionsActivityViewPopulator
{
}