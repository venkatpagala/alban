package org.andromda.cartridges.jsf.tests.hyperlinkactions;

/**
 * Provides the ability to populate any view in the Hyperlinkactions
 */
public final class HyperlinkactionsViewPopulator
{
    public static void populateForm(ShowSomethingParamhrefFormImpl fromForm, ShowSomethingParamhrefFormImpl toForm)
    {
        toForm.setSomeParameter(fromForm.getSomeParameter());
        toForm.setParameterWithDefaultValue(fromForm.getParameterWithDefaultValue());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingNoparamhrefFormImpl fromForm, ShowSomethingParamhrefFormImpl toForm)
    {
        toForm.setSomeParameter(fromForm.getSomeParameter());
        toForm.setParameterWithDefaultValue(fromForm.getParameterWithDefaultValue());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(HyperlinkactionsFormImpl fromForm, ShowSomethingParamhrefFormImpl toForm)
    {
        toForm.setSomeParameter(fromForm.getSomeParameter());
        toForm.setParameterWithDefaultValue(fromForm.getParameterWithDefaultValue());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingParamhrefFormImpl fromForm, ShowSomethingNoparamhrefFormImpl toForm)
    {
        toForm.setSomeParameter(fromForm.getSomeParameter());
        toForm.setParameterWithDefaultValue(fromForm.getParameterWithDefaultValue());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(ShowSomethingNoparamhrefFormImpl fromForm, ShowSomethingNoparamhrefFormImpl toForm)
    {
        toForm.setSomeParameter(fromForm.getSomeParameter());
        toForm.setParameterWithDefaultValue(fromForm.getParameterWithDefaultValue());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(HyperlinkactionsFormImpl fromForm, ShowSomethingNoparamhrefFormImpl toForm)
    {
        toForm.setSomeParameter(fromForm.getSomeParameter());
        toForm.setParameterWithDefaultValue(fromForm.getParameterWithDefaultValue());
        toForm.resetIsSetFlags();
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, ShowSomethingParamhrefFormImpl toForm)
    {
        if(fromForm instanceof ShowSomethingParamhrefFormImpl)
        {
            populateForm((ShowSomethingParamhrefFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ShowSomethingNoparamhrefFormImpl)
        {
            populateForm((ShowSomethingNoparamhrefFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof HyperlinkactionsFormImpl)
        {
            populateForm((HyperlinkactionsFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, ShowSomethingNoparamhrefFormImpl toForm)
    {
        if(fromForm instanceof ShowSomethingParamhrefFormImpl)
        {
            populateForm((ShowSomethingParamhrefFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof ShowSomethingNoparamhrefFormImpl)
        {
            populateForm((ShowSomethingNoparamhrefFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof HyperlinkactionsFormImpl)
        {
            populateForm((HyperlinkactionsFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}