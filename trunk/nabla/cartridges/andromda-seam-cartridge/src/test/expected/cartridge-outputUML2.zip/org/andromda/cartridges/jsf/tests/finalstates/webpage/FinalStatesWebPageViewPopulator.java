package org.andromda.cartridges.jsf.tests.finalstates.webpage;

/**
 * Provides the ability to populate any view in the FinalStatesWebPage
 */
public final class FinalStatesWebPageViewPopulator
{
}