package org.andromda.cartridges.jsf.tests.pagevariables;

import java.util.Map;

/**
 * Provides the ability to populate any view in the PageVariables
 */
public final class PageVariablesViewPopulator
{
    public static void populateForm(ShowSomethingSubmitFormImpl fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        toForm.setA(fromForm.getA());
        toForm.setB(fromForm.getB());
        toForm.setC(fromForm.getC());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(PageVariablesFormImpl fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        toForm.setA(fromForm.getA());
        toForm.setB(fromForm.getB());
        toForm.setC(fromForm.getC());
        toForm.resetIsSetFlags();
    }

    public static void populateShowSomethingPageVariables(Object fromForm, Map<String,Object> pageVariables)
    {
        if(fromForm instanceof ShowSomethingSubmitFormImpl)
        {
            final ShowSomethingSubmitFormImpl sourceForm=(ShowSomethingSubmitFormImpl)fromForm;
            if(sourceForm.isASet())
            {
                pageVariables.put("a",sourceForm.getA());
            }
            if(sourceForm.isBSet())
            {
                pageVariables.put("b",sourceForm.getB());
            }
            if(sourceForm.isCSet())
            {
                pageVariables.put("c",sourceForm.getC());
            }
        }
        else if(fromForm instanceof PageVariablesFormImpl)
        {
            final PageVariablesFormImpl sourceForm=(PageVariablesFormImpl)fromForm;
            if(sourceForm.isASet())
            {
                pageVariables.put("a",sourceForm.getA());
            }
            if(sourceForm.isBSet())
            {
                pageVariables.put("b",sourceForm.getB());
            }
            if(sourceForm.isCSet())
            {
                pageVariables.put("c",sourceForm.getC());
            }
        }
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, ShowSomethingSubmitFormImpl toForm)
    {
        if(fromForm instanceof ShowSomethingSubmitFormImpl)
        {
            populateForm((ShowSomethingSubmitFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof PageVariablesFormImpl)
        {
            populateForm((PageVariablesFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}