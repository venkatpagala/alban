package org.andromda.cartridges.jsf.tests.constraints.jsps.cannotdefercanstop;

/**
 * Provides the ability to populate any view in the JspsCannotDeferCanStop
 */
public final class JspsCannotDeferCanStopViewPopulator
{
}