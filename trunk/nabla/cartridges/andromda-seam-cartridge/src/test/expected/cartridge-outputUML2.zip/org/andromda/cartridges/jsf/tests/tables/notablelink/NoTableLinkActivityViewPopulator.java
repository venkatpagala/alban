package org.andromda.cartridges.jsf.tests.tables.notablelink;

import java.util.Map;

/**
 * Provides the ability to populate any view in the No Table Link Activity
 */
public final class NoTableLinkActivityViewPopulator
{
    public static void populateForm(ShowTableDataAgainFormImpl fromForm, ShowTableDataAgainFormImpl toForm)
    {
        toForm.setTableDatas(fromForm.getTableDatas());
        toForm.setCustomTables(fromForm.getCustomTables());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(NoTableLinkActivityFormImpl fromForm, ShowTableDataAgainFormImpl toForm)
    {
        toForm.setTableDatas(fromForm.getTableDatas());
        toForm.setCustomTables(fromForm.getCustomTables());
        toForm.resetIsSetFlags();
    }

    public static void populateShowTableDataPageVariables(Object fromForm, Map<String,Object> pageVariables)
    {
        if(fromForm instanceof ShowTableDataAgainFormImpl)
        {
            final ShowTableDataAgainFormImpl sourceForm=(ShowTableDataAgainFormImpl)fromForm;
            if(sourceForm.isTableDatasSet())
            {
                pageVariables.put("tableDatas",sourceForm.getTableDatas());
            }
            if(sourceForm.isCustomTablesSet())
            {
                pageVariables.put("customTables",sourceForm.getCustomTables());
            }
        }
        else if(fromForm instanceof NoTableLinkActivityFormImpl)
        {
            final NoTableLinkActivityFormImpl sourceForm=(NoTableLinkActivityFormImpl)fromForm;
            if(sourceForm.isTableDatasSet())
            {
                pageVariables.put("tableDatas",sourceForm.getTableDatas());
            }
            if(sourceForm.isCustomTablesSet())
            {
                pageVariables.put("customTables",sourceForm.getCustomTables());
            }
        }
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, ShowTableDataAgainFormImpl toForm)
    {
        if(fromForm instanceof ShowTableDataAgainFormImpl)
        {
            populateForm((ShowTableDataAgainFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof NoTableLinkActivityFormImpl)
        {
            populateForm((NoTableLinkActivityFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}