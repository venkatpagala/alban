package org.andromda.cartridges.jsf.tests.deferringoperations;

import java.util.Map;

/**
 * Provides the ability to populate any view in the DeferringOperations
 */
public final class DeferringOperationsViewPopulator
{
    public static void populateForm(State2Trigger2FormImpl fromForm, State2Trigger2FormImpl toForm)
    {
        toForm.setTestParam2(fromForm.getTestParam2());
        toForm.setTestParam2ValueList(fromForm.getTestParam2ValueList());
        toForm.setTestParam2LabelList(fromForm.getTestParam2LabelList());
        toForm.setParam4(fromForm.getParam4());
        toForm.setDecisionTestParam(fromForm.getDecisionTestParam());
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(State2Trigger2bFormImpl fromForm, State2Trigger2FormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(State4Trigger4FormImpl fromForm, State2Trigger2FormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.setTestParam2(fromForm.getTestParam2());
        toForm.setTestParam2ValueList(fromForm.getTestParam2ValueList());
        toForm.setTestParam2LabelList(fromForm.getTestParam2LabelList());
        toForm.setParam4(fromForm.getParam4());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(State4FormImpl fromForm, State2Trigger2FormImpl toForm)
    {
        toForm.setDecisionTestParam(fromForm.getDecisionTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(DeferringOperationsFormImpl fromForm, State2Trigger2FormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(State2Trigger2FormImpl fromForm, State2Trigger2bFormImpl toForm)
    {
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(State2Trigger2bFormImpl fromForm, State2Trigger2bFormImpl toForm)
    {
        toForm.setPageVariable(fromForm.getPageVariable());
        toForm.setTestParam(fromForm.getTestParam());
        toForm.setParam2a(fromForm.getParam2a());
        toForm.setTestParam2(fromForm.getTestParam2());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(State4Trigger4FormImpl fromForm, State2Trigger2bFormImpl toForm)
    {
        toForm.setPageVariable(fromForm.getPageVariable());
        toForm.setTestParam(fromForm.getTestParam());
        toForm.setParam2a(fromForm.getParam2a());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(DeferringOperationsFormImpl fromForm, State2Trigger2bFormImpl toForm)
    {
        toForm.setPageVariable(fromForm.getPageVariable());
        toForm.setTestParam(fromForm.getTestParam());
        toForm.setParam2a(fromForm.getParam2a());
        toForm.setTestParam2(fromForm.getTestParam2());
        toForm.resetIsSetFlags();
    }

    public static void populateState2PageVariables(Object fromForm, Map<String,Object> pageVariables)
    {
        if(fromForm instanceof State2Trigger2bFormImpl)
        {
            final State2Trigger2bFormImpl sourceForm=(State2Trigger2bFormImpl)fromForm;
            if(sourceForm.isPageVariableSet())
            {
                pageVariables.put("pageVariable",sourceForm.getPageVariable());
            }
        }
        else if(fromForm instanceof State4Trigger4FormImpl)
        {
            final State4Trigger4FormImpl sourceForm=(State4Trigger4FormImpl)fromForm;
            if(sourceForm.isPageVariableSet())
            {
                pageVariables.put("pageVariable",sourceForm.getPageVariable());
            }
        }
        else if(fromForm instanceof DeferringOperationsFormImpl)
        {
            final DeferringOperationsFormImpl sourceForm=(DeferringOperationsFormImpl)fromForm;
            if(sourceForm.isPageVariableSet())
            {
                pageVariables.put("pageVariable",sourceForm.getPageVariable());
            }
        }
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, State2Trigger2FormImpl toForm)
    {
        if(fromForm instanceof State2Trigger2FormImpl)
        {
            populateForm((State2Trigger2FormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof State2Trigger2bFormImpl)
        {
            populateForm((State2Trigger2bFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof State4Trigger4FormImpl)
        {
            populateForm((State4Trigger4FormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof State4FormImpl)
        {
            populateForm((State4FormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof DeferringOperationsFormImpl)
        {
            populateForm((DeferringOperationsFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, State2Trigger2bFormImpl toForm)
    {
        if(fromForm instanceof State2Trigger2FormImpl)
        {
            populateForm((State2Trigger2FormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof State2Trigger2bFormImpl)
        {
            populateForm((State2Trigger2bFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof State4Trigger4FormImpl)
        {
            populateForm((State4Trigger4FormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof DeferringOperationsFormImpl)
        {
            populateForm((DeferringOperationsFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
    public static void populateForm(State2Trigger2FormImpl fromForm, State4Trigger4FormImpl toForm)
    {
        toForm.setTestParam2(fromForm.getTestParam2());
        toForm.setTestParam2ValueList(fromForm.getTestParam2ValueList());
        toForm.setTestParam2LabelList(fromForm.getTestParam2LabelList());
        toForm.setParam4(fromForm.getParam4());
        toForm.setTestParam(fromForm.getTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(State2Trigger2bFormImpl fromForm, State4Trigger4FormImpl toForm)
    {
        toForm.setPageVariable(fromForm.getPageVariable());
        toForm.setTestParam(fromForm.getTestParam());
        toForm.setParam2a(fromForm.getParam2a());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(State4Trigger4FormImpl fromForm, State4Trigger4FormImpl toForm)
    {
        toForm.setPageVariable(fromForm.getPageVariable());
        toForm.setTestParam(fromForm.getTestParam());
        toForm.setParam2a(fromForm.getParam2a());
        toForm.setTestParam2(fromForm.getTestParam2());
        toForm.setTestParam2ValueList(fromForm.getTestParam2ValueList());
        toForm.setTestParam2LabelList(fromForm.getTestParam2LabelList());
        toForm.setParam4(fromForm.getParam4());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(DeferringOperationsFormImpl fromForm, State4Trigger4FormImpl toForm)
    {
        toForm.setPageVariable(fromForm.getPageVariable());
        toForm.setTestParam(fromForm.getTestParam());
        toForm.setParam2a(fromForm.getParam2a());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(State2Trigger2FormImpl fromForm, State4FormImpl toForm)
    {
        toForm.setDecisionTestParam(fromForm.getDecisionTestParam());
        toForm.resetIsSetFlags();
    }

    public static void populateForm(State4FormImpl fromForm, State4FormImpl toForm)
    {
        toForm.setDecisionTestParam(fromForm.getDecisionTestParam());
        toForm.resetIsSetFlags();
    }

    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, State4Trigger4FormImpl toForm)
    {
        if(fromForm instanceof State2Trigger2FormImpl)
        {
            populateForm((State2Trigger2FormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof State2Trigger2bFormImpl)
        {
            populateForm((State2Trigger2bFormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof State4Trigger4FormImpl)
        {
            populateForm((State4Trigger4FormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof DeferringOperationsFormImpl)
        {
            populateForm((DeferringOperationsFormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateForm(Object fromForm, State4FormImpl toForm)
    {
        if(fromForm instanceof State2Trigger2FormImpl)
        {
            populateForm((State2Trigger2FormImpl)fromForm,toForm);
        }
        else if(fromForm instanceof State4FormImpl)
        {
            populateForm((State4FormImpl)fromForm,toForm);
        }
        toForm.resetIsSetFlags();
    }
    
}