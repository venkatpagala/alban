/* --------------- EntityFive table definition --------------------- */
CREATE TABLE ENTITY_FIVE 
(
    ID NUMBER(19) NOT NULL,
    MANY2_MANY_ONE_FK NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */
CREATE INDEX IDXMANY2MANYONEENTITYFIVE ON ENTITY_FIVE
(
       MANY2_MANY_ONE_FK
);


/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_FIVE
   ADD  ( CONSTRAINT XPKENTITYFIVE PRIMARY KEY (ID) );
