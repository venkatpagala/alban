package org.andromda.presentation.jsf;

/**
 * Provides utilities for population of forms
 * when using JSF.
 *
 * @author Chad Brandon
 */
public class FormPopulator
    implements java.io.Serializable
{
    /**
     * Populates the form from the given parameters.  If the request parameter is null or an empty
     * string, then null is placed on the form.
     *
     * @param fromForm the form from which we're populating
     * @param toForm the form to which we're populating
     */
    public static final void populateForm(final Object fromForm, final Object toForm)
    {
        populateForm(fromForm, toForm, false);
    }
    
    /**
     * Populates the form from the given parameters.  If the request parameter is null or an empty
     * string, then null is placed on the form.
     *
     * @param fromForm the form from which we're populating
     * @param toForm the form to which we're populating
     * @param override whether or not properties that have already been copied, should be overridden.
     */
    public static final void populateForm(final Object fromForm, final Object toForm, boolean override)
    {
        if (fromForm != null && toForm != null)
        {
            try
            {
                final java.util.Map parameters = org.apache.commons.beanutils.PropertyUtils.describe(fromForm);
                for (final java.util.Iterator iterator = parameters.keySet().iterator(); iterator.hasNext();)
                {
                    final String name = (java.lang.String)iterator.next();
                    if (org.apache.commons.beanutils.PropertyUtils.isWriteable(toForm, name))
                    {
                        // - the property name used for checking whether or not the property value has been set
                        final String isSetPropertyName = name + "Set";
                        java.lang.Boolean isToFormPropertySet = null;
                        java.lang.Boolean isFromFormPropertySet = null;
                        // - only if override isn't true do we care whether or not the to property has been populated
                        if (!override)
                        {
                            if (org.apache.commons.beanutils.PropertyUtils.isReadable(toForm, isSetPropertyName))
                            {
                                isToFormPropertySet = (java.lang.Boolean)org.apache.commons.beanutils.PropertyUtils.getProperty(toForm, isSetPropertyName);
                            }
                        }
                        // - only if override is set to true, do we check to see if the from form property has been set
                        if (override)
                        {
                            if (org.apache.commons.beanutils.PropertyUtils.isReadable(fromForm, isSetPropertyName))
                            {
                                isFromFormPropertySet = (java.lang.Boolean)org.apache.commons.beanutils.PropertyUtils.getProperty(fromForm, isSetPropertyName);
                            }
                        }
                        if (!override || (override && isFromFormPropertySet != null && isFromFormPropertySet.booleanValue()))
                        {
                            if (override || (isToFormPropertySet == null || !isToFormPropertySet.booleanValue()))
                            {
                                final java.beans.PropertyDescriptor toDescriptor =
                                    org.apache.commons.beanutils.PropertyUtils.getPropertyDescriptor(toForm, name);
                                if (toDescriptor != null)
                                {
                                    java.lang.Object fromValue = parameters.get(name);
                                    // - only populate if not null
                                    if (fromValue != null)
                                    {
                                        final java.beans.PropertyDescriptor fromDescriptor =
                                            org.apache.commons.beanutils.PropertyUtils.getPropertyDescriptor(fromForm, name);
                                        // - only attempt to set if the types match
                                        if (fromDescriptor.getPropertyType() == toDescriptor.getPropertyType())
                                        {
                                            org.apache.commons.beanutils.PropertyUtils.setProperty(toForm, name, fromValue);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
}