// license-header java merge-point
package org.andromda.cartridges.jsf.tests.validation;

/**
 * @see org.andromda.cartridges.jsf.tests.validation.Controller
 */
public class ControllerImpl
    extends Controller
{

}