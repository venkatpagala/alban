// license-header java merge-point
package org.andromda.cartridges.jsf.tests.redirect;

/**
 * @see org.andromda.cartridges.jsf.tests.redirect.Controller
 */
public class ControllerImpl
    extends Controller
{

}