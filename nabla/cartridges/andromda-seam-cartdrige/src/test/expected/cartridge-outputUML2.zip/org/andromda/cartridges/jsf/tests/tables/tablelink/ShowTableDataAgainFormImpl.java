// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

/**
 * 
 */
public class ShowTableDataAgainFormImpl
    implements java.io.Serializable
{
    public ShowTableDataAgainFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.lang.String second;

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }

    /**
     * Keeps track of whether or not the value of second has
     * be populated at least once.
     */
    private boolean secondSet = false;

    /**
     * Indicates whether or not the value for second has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSecondSet()
    {
        return this.secondSet;
    }

    /**
     * 
     */
    public void setSecond(java.lang.String second)
    {
        this.second = second;
        this.secondSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] secondValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] secondLabelList;
    public java.lang.Object[] getSecondBackingList()
    {
        java.lang.Object[] values = this.secondValueList;
        java.lang.Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(java.lang.Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public java.lang.Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(java.lang.Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    public void setSecondBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataAgainFormImpl.setSecondBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.secondValueList = null;
        this.secondLabelList = null;
        if (items != null)
        {
            this.secondValueList = new java.lang.Object[items.size()];
            this.secondLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.secondValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.secondLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String third;

    /**
     * 
     */
    public java.lang.String getThird()
    {
        return this.third;
    }

    /**
     * Keeps track of whether or not the value of third has
     * be populated at least once.
     */
    private boolean thirdSet = false;

    /**
     * Indicates whether or not the value for third has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThirdSet()
    {
        return this.thirdSet;
    }

    /**
     * 
     */
    public void setThird(java.lang.String third)
    {
        this.third = third;
        this.thirdSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] thirdValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] thirdLabelList;
    public java.lang.Object[] getThirdBackingList()
    {
        java.lang.Object[] values = this.thirdValueList;
        java.lang.Object[] labels = this.thirdLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getThirdValueList()
    {
        return this.thirdValueList;
    }

    public void setThirdValueList(java.lang.Object[] thirdValueList)
    {
        this.thirdValueList = thirdValueList;
    }

    public java.lang.Object[] getThirdLabelList()
    {
        return this.thirdLabelList;
    }

    public void setThirdLabelList(java.lang.Object[] thirdLabelList)
    {
        this.thirdLabelList = thirdLabelList;
    }

    public void setThirdBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataAgainFormImpl.setThirdBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.thirdValueList = null;
        this.thirdLabelList = null;
        if (items != null)
        {
            this.thirdValueList = new java.lang.Object[items.size()];
            this.thirdLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.thirdValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.thirdLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String fourth;

    /**
     * 
     */
    public java.lang.String getFourth()
    {
        return this.fourth;
    }

    /**
     * Keeps track of whether or not the value of fourth has
     * be populated at least once.
     */
    private boolean fourthSet = false;

    /**
     * Indicates whether or not the value for fourth has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFourthSet()
    {
        return this.fourthSet;
    }

    /**
     * 
     */
    public void setFourth(java.lang.String fourth)
    {
        this.fourth = fourth;
        this.fourthSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] fourthValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] fourthLabelList;
    public java.lang.Object[] getFourthBackingList()
    {
        java.lang.Object[] values = this.fourthValueList;
        java.lang.Object[] labels = this.fourthLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getFourthValueList()
    {
        return this.fourthValueList;
    }

    public void setFourthValueList(java.lang.Object[] fourthValueList)
    {
        this.fourthValueList = fourthValueList;
    }

    public java.lang.Object[] getFourthLabelList()
    {
        return this.fourthLabelList;
    }

    public void setFourthLabelList(java.lang.Object[] fourthLabelList)
    {
        this.fourthLabelList = fourthLabelList;
    }

    public void setFourthBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataAgainFormImpl.setFourthBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.fourthValueList = null;
        this.fourthLabelList = null;
        if (items != null)
        {
            this.fourthValueList = new java.lang.Object[items.size()];
            this.fourthLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.fourthValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.fourthLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }
    
    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();
    
    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     * 
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }
    
    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message 
     * instances stored within this form.
     * 
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 289748190800866424L;
}