// license-header java merge-point
package org.andromda.cartridges.jsf.tests.deferringoperations;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>testPageToPage</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.deferringoperations.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#testPageToPage(int decisionTestParam)
 */
public interface TestPageToPageForm
{
    /**
     * 
     */
    public int getDecisionTestParam();

    /**
     * 
     */
    public void setDecisionTestParam(int decisionTestParam);
    
}