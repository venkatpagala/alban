// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase.Controller#OperationNameAsUseCase()
     */
    public void OperationNameAsUseCase()
    {
    }
    
}