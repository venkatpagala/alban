package org.andromda.cartridges.jsf.tests.tables.tablelink;

import java.io.IOException;

import javax.faces.FactoryFinder;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * This filter handles the population of forms for the <em>show table data</code>
 * view.
 */
public class ShowTableDataPopulator
    implements Filter
{
    private FilterConfig config;

    /**
     * Initialize the filter
     * 
     * @param config the configuration
     * @see javax.servlet.Filter#setFilterConfig(FilterConfig)
     */
    public void init(FilterConfig config)
    {
        this.config = config;
    }

    /**
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    public void doFilter(
        ServletRequest request,
        ServletResponse response,
        FilterChain chain) throws IOException, ServletException
    {
        this.populateFormAndViewVariables(request, response, null);
        chain.doFilter(request, response);
    }
    
    private void populateFormAndViewVariables(final ServletRequest request, final ServletResponse response, Object form)
        throws ServletException
    {
        // - we need to retrieve the faces context differently since we're outside of the
        //   faces servlet
        final LifecycleFactory lifecycleFactory =
            (LifecycleFactory)FactoryFinder.getFactory(FactoryFinder.LIFECYCLE_FACTORY);
        final Lifecycle lifecycle = lifecycleFactory.getLifecycle(LifecycleFactory.DEFAULT_LIFECYCLE);
        final FacesContextFactory facesContextFactory =
            (FacesContextFactory)FactoryFinder.getFactory(FactoryFinder.FACES_CONTEXT_FACTORY);
        final FacesContext facesContext =
            facesContextFactory.getFacesContext(
                this.config.getServletContext(),
                request,
                response,
                lifecycle);
                
        oracle.adf.view.faces.context.AdfFacesContext adfContext = oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance();
        final javax.faces.el.VariableResolver variableResolver = facesContext.getApplication().getVariableResolver();
        final javax.servlet.http.HttpSession session = ((javax.servlet.http.HttpServletRequest)request).getSession();
        if (form == null)
        {  
            // - first try getting the form from the ADF processScope
            form = adfContext.getProcessScope().get("form");
            // - if the form is null, try getting the current adfContext from the session (and then remove it from the session)
            if (form == null)
            {
                final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = 
                    (org.andromda.presentation.jsf.AdfFacesContextWrapper)session.getAttribute("AndroMDAADFContext");
                adfContext = contextWrapper != null ? contextWrapper.getCurrentInstance() : null;    
                form = adfContext != null ? adfContext.getProcessScope().get("form") : null;   
                // - if the form is still null, see if we can get it from a serialized state
                if (form == null)
                {
                    form = org.andromda.presentation.jsf.JsfUtils.getSerializedForm(session);
                }
                if (form != null)
                {
                    // - add the form to the current process scope since it wasn't in the current one to begin with
                    oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance().getProcessScope().put("form", form);   
                }
            }
            else
            {
                // - remove the ADF context in the event that its present
                session.removeAttribute("AndroMDAADFContext");
            }
        }
        else
        {
            // - since the form argument is not null, set it as the "form" in the processScope 
            //   (to replace the existing "form" attribute)
            adfContext.getProcessScope().put("form", form);
        }
        try
        {
            // - populate the forms
            if (form != null)
            {    
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAgainFormImpl tableLinkActivityShowTableDataAgainForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAgainFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataAgainForm");
                // - populate the tableLinkActivityShowTableDataAgainForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataAgainForm);
                request.setAttribute("tableLinkActivityShowTableDataAgainForm", tableLinkActivityShowTableDataAgainForm);
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionFormImpl tableLinkActivityShowTableDataHyperlinkActionForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataHyperlinkActionForm");
                // - populate the tableLinkActivityShowTableDataHyperlinkActionForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataHyperlinkActionForm);
                request.setAttribute("tableLinkActivityShowTableDataHyperlinkActionForm", tableLinkActivityShowTableDataHyperlinkActionForm);
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataBadActionFormImpl tableLinkActivityShowTableDataBadActionForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataBadActionFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataBadActionForm");
                // - populate the tableLinkActivityShowTableDataBadActionForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataBadActionForm);
                request.setAttribute("tableLinkActivityShowTableDataBadActionForm", tableLinkActivityShowTableDataBadActionForm);
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl tableLinkActivityShowTableDataHyperlinkActionDuplicatingParameterForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataHyperlinkActionDuplicatingParameterForm");
                // - populate the tableLinkActivityShowTableDataHyperlinkActionDuplicatingParameterForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataHyperlinkActionDuplicatingParameterForm);
                request.setAttribute("tableLinkActivityShowTableDataHyperlinkActionDuplicatingParameterForm", tableLinkActivityShowTableDataHyperlinkActionDuplicatingParameterForm);
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkNotSpecifyingColumnFormImpl tableLinkActivityShowTableDataHyperlinkNotSpecifyingColumnForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkNotSpecifyingColumnFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataHyperlinkNotSpecifyingColumnForm");
                // - populate the tableLinkActivityShowTableDataHyperlinkNotSpecifyingColumnForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataHyperlinkNotSpecifyingColumnForm);
                request.setAttribute("tableLinkActivityShowTableDataHyperlinkNotSpecifyingColumnForm", tableLinkActivityShowTableDataHyperlinkNotSpecifyingColumnForm);
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl tableLinkActivityShowTableDataActionWithBadTableLinkForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataActionWithBadTableLinkForm");
                // - populate the tableLinkActivityShowTableDataActionWithBadTableLinkForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataActionWithBadTableLinkForm);
                request.setAttribute("tableLinkActivityShowTableDataActionWithBadTableLinkForm", tableLinkActivityShowTableDataActionWithBadTableLinkForm);
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataRealisticFormActionFormImpl tableLinkActivityShowTableDataRealisticFormActionForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataRealisticFormActionFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataRealisticFormActionForm");
                // - populate the tableLinkActivityShowTableDataRealisticFormActionForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataRealisticFormActionForm);
                request.setAttribute("tableLinkActivityShowTableDataRealisticFormActionForm", tableLinkActivityShowTableDataRealisticFormActionForm);
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataImageLinkActionFormImpl tableLinkActivityShowTableDataImageLinkActionForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataImageLinkActionFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataImageLinkActionForm");
                // - populate the tableLinkActivityShowTableDataImageLinkActionForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataImageLinkActionForm);
                request.setAttribute("tableLinkActivityShowTableDataImageLinkActionForm", tableLinkActivityShowTableDataImageLinkActionForm);
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataGlobalTableActionFormImpl tableLinkActivityShowTableDataGlobalTableActionForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataGlobalTableActionFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataGlobalTableActionForm");
                // - populate the tableLinkActivityShowTableDataGlobalTableActionForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataGlobalTableActionForm);
                request.setAttribute("tableLinkActivityShowTableDataGlobalTableActionForm", tableLinkActivityShowTableDataGlobalTableActionForm);
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataDuplicateGlobalTableActionFormImpl tableLinkActivityShowTableDataDuplicateGlobalTableActionForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataDuplicateGlobalTableActionFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataDuplicateGlobalTableActionForm");
                // - populate the tableLinkActivityShowTableDataDuplicateGlobalTableActionForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataDuplicateGlobalTableActionForm);
                request.setAttribute("tableLinkActivityShowTableDataDuplicateGlobalTableActionForm", tableLinkActivityShowTableDataDuplicateGlobalTableActionForm);
                org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAnotherDuplicateGlobalTableActionFormImpl tableLinkActivityShowTableDataAnotherDuplicateGlobalTableActionForm =
                    (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAnotherDuplicateGlobalTableActionFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "tableLinkActivityShowTableDataAnotherDuplicateGlobalTableActionForm");
                // - populate the tableLinkActivityShowTableDataAnotherDuplicateGlobalTableActionForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, tableLinkActivityShowTableDataAnotherDuplicateGlobalTableActionForm);
                request.setAttribute("tableLinkActivityShowTableDataAnotherDuplicateGlobalTableActionForm", tableLinkActivityShowTableDataAnotherDuplicateGlobalTableActionForm);
            }
            // - serialize the form
            if (form != null)
            {
                org.andromda.presentation.jsf.JsfUtils.serializeForm(session, form);
            }
            // - populate the view variables
            if (form != null)
            {    
                final boolean tableDataReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "tableData");
                if (tableDataReadable)
                {
                    request.setAttribute("tableData", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "tableData"));
                }
                final boolean multiboxThingReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "multiboxThing");
                if (multiboxThingReadable)
                {
                    request.setAttribute("multiboxThing", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "multiboxThing"));
                }
                final boolean tableDataDefaultExportTypesReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "tableDataDefaultExportTypes");
                if (tableDataDefaultExportTypesReadable)
                {
                    request.setAttribute("tableDataDefaultExportTypes", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "tableDataDefaultExportTypes"));
                }
                final boolean tableDataNoExportTypesReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "tableDataNoExportTypes");
                if (tableDataNoExportTypesReadable)
                {
                    request.setAttribute("tableDataNoExportTypes", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "tableDataNoExportTypes"));
                }
                final boolean tableDataNotSortableReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "tableDataNotSortable");
                if (tableDataNotSortableReadable)
                {
                    request.setAttribute("tableDataNotSortable", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "tableDataNotSortable"));
                }
                final boolean firstReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "first");
                if (firstReadable)
                {
                    request.setAttribute("first", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "first"));
                }
                final boolean thirdReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "third");
                if (thirdReadable)
                {
                    request.setAttribute("third", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "third"));
                }
                final boolean twoReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "two");
                if (twoReadable)
                {
                    request.setAttribute("two", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "two"));
                }
                final boolean secondReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "second");
                if (secondReadable)
                {
                    request.setAttribute("second", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "second"));
                }
                final boolean formParam1Readable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "formParam1");
                if (formParam1Readable)
                {
                    request.setAttribute("formParam1", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "formParam1"));
                }
                final boolean formParam2Readable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "formParam2");
                if (formParam2Readable)
                {
                    request.setAttribute("formParam2", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "formParam2"));
                }
                final boolean parameterWithDefaultValueReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "parameterWithDefaultValue");
                if (parameterWithDefaultValueReadable)
                {
                    request.setAttribute("parameterWithDefaultValue", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "parameterWithDefaultValue"));
                }
                final boolean fourthReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "fourth");
                if (fourthReadable)
                {
                    request.setAttribute("fourth", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "fourth"));
                }
                final boolean thisOneShouldbeNamedFirstReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "thisOneShouldbeNamedFirst");
                if (thisOneShouldbeNamedFirstReadable)
                {
                    request.setAttribute("thisOneShouldbeNamedFirst", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "thisOneShouldbeNamedFirst"));
                }
                final boolean fourthBackingListReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "fourthBackingList");
                if (fourthBackingListReadable)
                {
                    request.setAttribute("fourthBackingList", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "fourthBackingList"));
                }
            }
        }
        catch (final Throwable throwable)
        {
            throw new ServletException(throwable);
        }
    }

    /**
     * @see javax.servlet.Filter#destroy()
     */
    public void destroy()
    {
        this.config = null;
    }
}