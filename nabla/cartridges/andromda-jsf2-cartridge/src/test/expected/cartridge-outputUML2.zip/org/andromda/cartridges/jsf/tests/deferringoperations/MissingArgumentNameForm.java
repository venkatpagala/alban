// license-header java merge-point
package org.andromda.cartridges.jsf.tests.deferringoperations;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>missingArgumentName</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.deferringoperations.Controller</code> controller.
 *
 * <p>
 * This operation exists to test that parameters must have a
 * non-empty name.
 * </p>
 *
 * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#missingArgumentName(java.lang.String )
 */
public interface MissingArgumentNameForm
{
    /**
     * Gets the ValueChangeEvent (if any) that is associated with this form.
     * 
     * @return the faces ValueChangeEvent associated to this form.
     */
    public javax.faces.event.ValueChangeEvent getValueChangeEvent();
    
    /**
     * Gets the ActionEvent (if any) that is associated with this form.
     * 
     * @return the faces ActionEvent associated to this form.
     */
    public javax.faces.event.ActionEvent getActionEvent();
    
    /**
     * Sets the event (if any) that is associated with this form.
     * 
     * @param event the faces event to associate to this form.
     */
    public void setEvent(javax.faces.event.FacesEvent event);
    
    /**
     * 
     */
    public java.lang.String get();

    /**
     * 
     */
    public void set(java.lang.String );

}
