// license-header java merge-point
package org.andromda.cartridges.jsf.tests.widgets;

/**
 * 
 */
public class ShowWidgetsSubmitFormImpl
    implements java.io.Serializable
{
    public ShowWidgetsSubmitFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        final java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient javax.faces.event.FacesEvent event;

    public void setEvent(javax.faces.event.FacesEvent event)
    {
        this.event = event;
    }

    public javax.faces.event.ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof javax.faces.event.ValueChangeEvent
            ? (javax.faces.event.ValueChangeEvent)this.event : null;
    }

    public javax.faces.event.ActionEvent getActionEvent()
    {
        return this.event instanceof javax.faces.event.ActionEvent
            ? (javax.faces.event.ActionEvent)this.event : null;
    }

    private java.lang.String textFieldTest;

    /**
     * 
     */
    public java.lang.String getTextFieldTest()
    {
        return this.textFieldTest;
    }

    /**
     * Keeps track of whether or not the value of textFieldTest has
     * be populated at least once.
     */
    private boolean textFieldTestSet = false;

    /**
     * Resets the value of the textFieldTestSet to false
     */
    public void resetTextFieldTestSet()
    {
        this.textFieldTestSet = false;
    }

    /**
     * Indicates whether or not the value for textFieldTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTextFieldTestSet()
    {
        return this.textFieldTestSet;
    }

    /**
     * 
     */
    public void setTextFieldTest(java.lang.String textFieldTest)
    {
        this.textFieldTest = textFieldTest;
        this.textFieldTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] textFieldTestValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] textFieldTestLabelList;
    public java.lang.Object[] getTextFieldTestBackingList()
    {
        java.lang.Object[] values = this.textFieldTestValueList;
        java.lang.Object[] labels = this.textFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getTextFieldTestValueList()
    {
        return this.textFieldTestValueList;
    }

    public void setTextFieldTestValueList(java.lang.Object[] textFieldTestValueList)
    {
        this.textFieldTestValueList = textFieldTestValueList;
    }

    public java.lang.Object[] getTextFieldTestLabelList()
    {
        return this.textFieldTestLabelList;
    }

    public void setTextFieldTestLabelList(java.lang.Object[] textFieldTestLabelList)
    {
        this.textFieldTestLabelList = textFieldTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTextFieldTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.textFieldTestValueList = null;
        this.textFieldTestLabelList = null;
        if (items != null)
        {
            this.textFieldTestValueList = new java.lang.Object[items.size()];
            this.textFieldTestLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.textFieldTestValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.textFieldTestLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.textFieldTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String passwordFieldTest;

    /**
     * 
     */
    public java.lang.String getPasswordFieldTest()
    {
        return this.passwordFieldTest;
    }

    /**
     * Keeps track of whether or not the value of passwordFieldTest has
     * be populated at least once.
     */
    private boolean passwordFieldTestSet = false;

    /**
     * Resets the value of the passwordFieldTestSet to false
     */
    public void resetPasswordFieldTestSet()
    {
        this.passwordFieldTestSet = false;
    }

    /**
     * Indicates whether or not the value for passwordFieldTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isPasswordFieldTestSet()
    {
        return this.passwordFieldTestSet;
    }

    /**
     * 
     */
    public void setPasswordFieldTest(java.lang.String passwordFieldTest)
    {
        this.passwordFieldTest = passwordFieldTest;
        this.passwordFieldTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] passwordFieldTestValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] passwordFieldTestLabelList;
    public java.lang.Object[] getPasswordFieldTestBackingList()
    {
        java.lang.Object[] values = this.passwordFieldTestValueList;
        java.lang.Object[] labels = this.passwordFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getPasswordFieldTestValueList()
    {
        return this.passwordFieldTestValueList;
    }

    public void setPasswordFieldTestValueList(java.lang.Object[] passwordFieldTestValueList)
    {
        this.passwordFieldTestValueList = passwordFieldTestValueList;
    }

    public java.lang.Object[] getPasswordFieldTestLabelList()
    {
        return this.passwordFieldTestLabelList;
    }

    public void setPasswordFieldTestLabelList(java.lang.Object[] passwordFieldTestLabelList)
    {
        this.passwordFieldTestLabelList = passwordFieldTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setPasswordFieldTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.passwordFieldTestValueList = null;
        this.passwordFieldTestLabelList = null;
        if (items != null)
        {
            this.passwordFieldTestValueList = new java.lang.Object[items.size()];
            this.passwordFieldTestLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.passwordFieldTestValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.passwordFieldTestLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.passwordFieldTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String textAreaTest;

    /**
     * 
     */
    public java.lang.String getTextAreaTest()
    {
        return this.textAreaTest;
    }

    /**
     * Keeps track of whether or not the value of textAreaTest has
     * be populated at least once.
     */
    private boolean textAreaTestSet = false;

    /**
     * Resets the value of the textAreaTestSet to false
     */
    public void resetTextAreaTestSet()
    {
        this.textAreaTestSet = false;
    }

    /**
     * Indicates whether or not the value for textAreaTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTextAreaTestSet()
    {
        return this.textAreaTestSet;
    }

    /**
     * 
     */
    public void setTextAreaTest(java.lang.String textAreaTest)
    {
        this.textAreaTest = textAreaTest;
        this.textAreaTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] textAreaTestValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] textAreaTestLabelList;
    public java.lang.Object[] getTextAreaTestBackingList()
    {
        java.lang.Object[] values = this.textAreaTestValueList;
        java.lang.Object[] labels = this.textAreaTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getTextAreaTestValueList()
    {
        return this.textAreaTestValueList;
    }

    public void setTextAreaTestValueList(java.lang.Object[] textAreaTestValueList)
    {
        this.textAreaTestValueList = textAreaTestValueList;
    }

    public java.lang.Object[] getTextAreaTestLabelList()
    {
        return this.textAreaTestLabelList;
    }

    public void setTextAreaTestLabelList(java.lang.Object[] textAreaTestLabelList)
    {
        this.textAreaTestLabelList = textAreaTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTextAreaTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.textAreaTestValueList = null;
        this.textAreaTestLabelList = null;
        if (items != null)
        {
            this.textAreaTestValueList = new java.lang.Object[items.size()];
            this.textAreaTestLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.textAreaTestValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.textAreaTestLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.textAreaTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private boolean checkboxTest;

    /**
     * 
     */
    public boolean isCheckboxTest()
    {
        return this.checkboxTest;
    }

    /**
     * Keeps track of whether or not the value of checkboxTest has
     * be populated at least once.
     */
    private boolean checkboxTestSet = false;

    /**
     * Resets the value of the checkboxTestSet to false
     */
    public void resetCheckboxTestSet()
    {
        this.checkboxTestSet = false;
    }

    /**
     * Indicates whether or not the value for checkboxTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCheckboxTestSet()
    {
        return this.checkboxTestSet;
    }

    /**
     * 
     */
    public void setCheckboxTest(boolean checkboxTest)
    {
        this.checkboxTest = checkboxTest;
        this.checkboxTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] checkboxTestValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] checkboxTestLabelList;
    public java.lang.Object[] getCheckboxTestBackingList()
    {
        java.lang.Object[] values = this.checkboxTestValueList;
        java.lang.Object[] labels = this.checkboxTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getCheckboxTestValueList()
    {
        return this.checkboxTestValueList;
    }

    public void setCheckboxTestValueList(java.lang.Object[] checkboxTestValueList)
    {
        this.checkboxTestValueList = checkboxTestValueList;
    }

    public java.lang.Object[] getCheckboxTestLabelList()
    {
        return this.checkboxTestLabelList;
    }

    public void setCheckboxTestLabelList(java.lang.Object[] checkboxTestLabelList)
    {
        this.checkboxTestLabelList = checkboxTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCheckboxTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.checkboxTestValueList = null;
        this.checkboxTestLabelList = null;
        if (items != null)
        {
            this.checkboxTestValueList = new java.lang.Object[items.size()];
            this.checkboxTestLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.checkboxTestValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.checkboxTestLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.checkboxTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String radioButtonsTest;

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest()
    {
        return this.radioButtonsTest;
    }

    /**
     * Keeps track of whether or not the value of radioButtonsTest has
     * be populated at least once.
     */
    private boolean radioButtonsTestSet = false;

    /**
     * Resets the value of the radioButtonsTestSet to false
     */
    public void resetRadioButtonsTestSet()
    {
        this.radioButtonsTestSet = false;
    }

    /**
     * Indicates whether or not the value for radioButtonsTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isRadioButtonsTestSet()
    {
        return this.radioButtonsTestSet;
    }

    /**
     * 
     */
    public void setRadioButtonsTest(java.lang.String radioButtonsTest)
    {
        this.radioButtonsTest = radioButtonsTest;
        this.radioButtonsTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] radioButtonsTestValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] radioButtonsTestLabelList;
    public java.lang.Object[] getRadioButtonsTestBackingList()
    {
        java.lang.Object[] values = this.radioButtonsTestValueList;
        java.lang.Object[] labels = this.radioButtonsTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getRadioButtonsTestValueList()
    {
        return this.radioButtonsTestValueList;
    }

    public void setRadioButtonsTestValueList(java.lang.Object[] radioButtonsTestValueList)
    {
        this.radioButtonsTestValueList = radioButtonsTestValueList;
    }

    public java.lang.Object[] getRadioButtonsTestLabelList()
    {
        return this.radioButtonsTestLabelList;
    }

    public void setRadioButtonsTestLabelList(java.lang.Object[] radioButtonsTestLabelList)
    {
        this.radioButtonsTestLabelList = radioButtonsTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setRadioButtonsTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.radioButtonsTestValueList = null;
        this.radioButtonsTestLabelList = null;
        if (items != null)
        {
            this.radioButtonsTestValueList = new java.lang.Object[items.size()];
            this.radioButtonsTestLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.radioButtonsTestValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.radioButtonsTestLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.radioButtonsTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String radioButtonsTest2;

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest2()
    {
        return this.radioButtonsTest2;
    }

    /**
     * Keeps track of whether or not the value of radioButtonsTest2 has
     * be populated at least once.
     */
    private boolean radioButtonsTest2Set = false;

    /**
     * Resets the value of the radioButtonsTest2Set to false
     */
    public void resetRadioButtonsTest2Set()
    {
        this.radioButtonsTest2Set = false;
    }

    /**
     * Indicates whether or not the value for radioButtonsTest2 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isRadioButtonsTest2Set()
    {
        return this.radioButtonsTest2Set;
    }

    /**
     * 
     */
    public void setRadioButtonsTest2(java.lang.String radioButtonsTest2)
    {
        this.radioButtonsTest2 = radioButtonsTest2;
        this.radioButtonsTest2Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] radioButtonsTest2ValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] radioButtonsTest2LabelList;
    public java.lang.Object[] getRadioButtonsTest2BackingList()
    {
        java.lang.Object[] values = this.radioButtonsTest2ValueList;
        java.lang.Object[] labels = this.radioButtonsTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getRadioButtonsTest2ValueList()
    {
        return this.radioButtonsTest2ValueList;
    }

    public void setRadioButtonsTest2ValueList(java.lang.Object[] radioButtonsTest2ValueList)
    {
        this.radioButtonsTest2ValueList = radioButtonsTest2ValueList;
    }

    public java.lang.Object[] getRadioButtonsTest2LabelList()
    {
        return this.radioButtonsTest2LabelList;
    }

    public void setRadioButtonsTest2LabelList(java.lang.Object[] radioButtonsTest2LabelList)
    {
        this.radioButtonsTest2LabelList = radioButtonsTest2LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setRadioButtonsTest2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.radioButtonsTest2ValueList = null;
        this.radioButtonsTest2LabelList = null;
        if (items != null)
        {
            this.radioButtonsTest2ValueList = new java.lang.Object[items.size()];
            this.radioButtonsTest2LabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.radioButtonsTest2ValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.radioButtonsTest2LabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.radioButtonsTest2LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String radioButtonsTest3;

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest3()
    {
        return this.radioButtonsTest3;
    }

    /**
     * Keeps track of whether or not the value of radioButtonsTest3 has
     * be populated at least once.
     */
    private boolean radioButtonsTest3Set = false;

    /**
     * Resets the value of the radioButtonsTest3Set to false
     */
    public void resetRadioButtonsTest3Set()
    {
        this.radioButtonsTest3Set = false;
    }

    /**
     * Indicates whether or not the value for radioButtonsTest3 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isRadioButtonsTest3Set()
    {
        return this.radioButtonsTest3Set;
    }

    /**
     * 
     */
    public void setRadioButtonsTest3(java.lang.String radioButtonsTest3)
    {
        this.radioButtonsTest3 = radioButtonsTest3;
        this.radioButtonsTest3Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] radioButtonsTest3ValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] radioButtonsTest3LabelList;
    public java.lang.Object[] getRadioButtonsTest3BackingList()
    {
        java.lang.Object[] values = this.radioButtonsTest3ValueList;
        java.lang.Object[] labels = this.radioButtonsTest3LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getRadioButtonsTest3ValueList()
    {
        return this.radioButtonsTest3ValueList;
    }

    public void setRadioButtonsTest3ValueList(java.lang.Object[] radioButtonsTest3ValueList)
    {
        this.radioButtonsTest3ValueList = radioButtonsTest3ValueList;
    }

    public java.lang.Object[] getRadioButtonsTest3LabelList()
    {
        return this.radioButtonsTest3LabelList;
    }

    public void setRadioButtonsTest3LabelList(java.lang.Object[] radioButtonsTest3LabelList)
    {
        this.radioButtonsTest3LabelList = radioButtonsTest3LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setRadioButtonsTest3BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.radioButtonsTest3ValueList = null;
        this.radioButtonsTest3LabelList = null;
        if (items != null)
        {
            this.radioButtonsTest3ValueList = new java.lang.Object[items.size()];
            this.radioButtonsTest3LabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.radioButtonsTest3ValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.radioButtonsTest3LabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.radioButtonsTest3LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String selectTest;

    /**
     * 
     */
    public java.lang.String getSelectTest()
    {
        return this.selectTest;
    }

    /**
     * Keeps track of whether or not the value of selectTest has
     * be populated at least once.
     */
    private boolean selectTestSet = false;

    /**
     * Resets the value of the selectTestSet to false
     */
    public void resetSelectTestSet()
    {
        this.selectTestSet = false;
    }

    /**
     * Indicates whether or not the value for selectTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSelectTestSet()
    {
        return this.selectTestSet;
    }

    /**
     * 
     */
    public void setSelectTest(java.lang.String selectTest)
    {
        this.selectTest = selectTest;
        this.selectTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] selectTestValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] selectTestLabelList;
    public java.lang.Object[] getSelectTestBackingList()
    {
        java.lang.Object[] values = this.selectTestValueList;
        java.lang.Object[] labels = this.selectTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getSelectTestValueList()
    {
        return this.selectTestValueList;
    }

    public void setSelectTestValueList(java.lang.Object[] selectTestValueList)
    {
        this.selectTestValueList = selectTestValueList;
    }

    public java.lang.Object[] getSelectTestLabelList()
    {
        return this.selectTestLabelList;
    }

    public void setSelectTestLabelList(java.lang.Object[] selectTestLabelList)
    {
        this.selectTestLabelList = selectTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setSelectTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.selectTestValueList = null;
        this.selectTestLabelList = null;
        if (items != null)
        {
            this.selectTestValueList = new java.lang.Object[items.size()];
            this.selectTestLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.selectTestValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.selectTestLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.selectTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String hiddenTest;

    /**
     * 
     */
    public java.lang.String getHiddenTest()
    {
        return this.hiddenTest;
    }

    /**
     * Keeps track of whether or not the value of hiddenTest has
     * be populated at least once.
     */
    private boolean hiddenTestSet = false;

    /**
     * Resets the value of the hiddenTestSet to false
     */
    public void resetHiddenTestSet()
    {
        this.hiddenTestSet = false;
    }

    /**
     * Indicates whether or not the value for hiddenTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isHiddenTestSet()
    {
        return this.hiddenTestSet;
    }

    /**
     * 
     */
    public void setHiddenTest(java.lang.String hiddenTest)
    {
        this.hiddenTest = hiddenTest;
        this.hiddenTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] hiddenTestValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] hiddenTestLabelList;
    public java.lang.Object[] getHiddenTestBackingList()
    {
        java.lang.Object[] values = this.hiddenTestValueList;
        java.lang.Object[] labels = this.hiddenTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getHiddenTestValueList()
    {
        return this.hiddenTestValueList;
    }

    public void setHiddenTestValueList(java.lang.Object[] hiddenTestValueList)
    {
        this.hiddenTestValueList = hiddenTestValueList;
    }

    public java.lang.Object[] getHiddenTestLabelList()
    {
        return this.hiddenTestLabelList;
    }

    public void setHiddenTestLabelList(java.lang.Object[] hiddenTestLabelList)
    {
        this.hiddenTestLabelList = hiddenTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setHiddenTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.hiddenTestValueList = null;
        this.hiddenTestLabelList = null;
        if (items != null)
        {
            this.hiddenTestValueList = new java.lang.Object[items.size()];
            this.hiddenTestLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.hiddenTestValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.hiddenTestLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.hiddenTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String textFieldTest2;

    /**
     * 
     */
    public java.lang.String getTextFieldTest2()
    {
        return this.textFieldTest2;
    }

    /**
     * Keeps track of whether or not the value of textFieldTest2 has
     * be populated at least once.
     */
    private boolean textFieldTest2Set = false;

    /**
     * Resets the value of the textFieldTest2Set to false
     */
    public void resetTextFieldTest2Set()
    {
        this.textFieldTest2Set = false;
    }

    /**
     * Indicates whether or not the value for textFieldTest2 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTextFieldTest2Set()
    {
        return this.textFieldTest2Set;
    }

    /**
     * 
     */
    public void setTextFieldTest2(java.lang.String textFieldTest2)
    {
        this.textFieldTest2 = textFieldTest2;
        this.textFieldTest2Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] textFieldTest2ValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] textFieldTest2LabelList;
    public java.lang.Object[] getTextFieldTest2BackingList()
    {
        java.lang.Object[] values = this.textFieldTest2ValueList;
        java.lang.Object[] labels = this.textFieldTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getTextFieldTest2ValueList()
    {
        return this.textFieldTest2ValueList;
    }

    public void setTextFieldTest2ValueList(java.lang.Object[] textFieldTest2ValueList)
    {
        this.textFieldTest2ValueList = textFieldTest2ValueList;
    }

    public java.lang.Object[] getTextFieldTest2LabelList()
    {
        return this.textFieldTest2LabelList;
    }

    public void setTextFieldTest2LabelList(java.lang.Object[] textFieldTest2LabelList)
    {
        this.textFieldTest2LabelList = textFieldTest2LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTextFieldTest2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.textFieldTest2ValueList = null;
        this.textFieldTest2LabelList = null;
        if (items != null)
        {
            this.textFieldTest2ValueList = new java.lang.Object[items.size()];
            this.textFieldTest2LabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.textFieldTest2ValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.textFieldTest2LabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.textFieldTest2LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetTextFieldTestSet();
         this.resetPasswordFieldTestSet();
         this.resetTextAreaTestSet();
         this.resetCheckboxTestSet();
         this.resetRadioButtonsTestSet();
         this.resetRadioButtonsTest2Set();
         this.resetRadioButtonsTest3Set();
         this.resetSelectTestSet();
         this.resetHiddenTestSet();
         this.resetTextFieldTest2Set();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map<java.lang.String, java.text.DateFormat> dateTimeFormatters =
        new java.util.HashMap<java.lang.String, java.text.DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map<java.lang.String, java.text.DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient java.util.Map<java.lang.String, javax.faces.application.FacesMessage> jsfMessages =
        new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection<javax.faces.application.FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection<javax.faces.application.FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public javax.faces.application.FacesMessage.Severity getMaximumMessageSeverity()
    {
        javax.faces.application.FacesMessage.Severity maxSeverity = null;
        for (final javax.faces.application.FacesMessage message : this.getJsfMessages())
        {
            final javax.faces.application.FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -429804311279173999L;
}
