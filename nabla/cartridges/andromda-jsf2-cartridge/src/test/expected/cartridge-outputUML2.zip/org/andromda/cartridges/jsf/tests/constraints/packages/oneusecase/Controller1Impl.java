// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase.Controller1
 */
public class Controller1Impl
    extends Controller1
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 2697549592596239781L;
    
}