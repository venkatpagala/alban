// license-header java merge-point
package org.andromda.cartridges.jsf.tests.graphoutusecase.usecase;

/**
 * @see org.andromda.cartridges.jsf.tests.graphoutusecase.usecase.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -2471582187370912958L;
    
}