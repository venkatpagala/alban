// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formfields;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>anotherOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.formfields.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.formfields.Controller#anotherOperation(java.lang.String notused, int unusedNumber)
 */
public interface AnotherOperationForm
{
    /**
     * Gets the ValueChangeEvent (if any) that is associated with this form.
     * 
     * @return the faces ValueChangeEvent associated to this form.
     */
    public javax.faces.event.ValueChangeEvent getValueChangeEvent();
    
    /**
     * Gets the ActionEvent (if any) that is associated with this form.
     * 
     * @return the faces ActionEvent associated to this form.
     */
    public javax.faces.event.ActionEvent getActionEvent();
    
    /**
     * Sets the event (if any) that is associated with this form.
     * 
     * @param event the faces event to associate to this form.
     */
    public void setEvent(javax.faces.event.FacesEvent event);
    
    /**
     * 
     */
    public java.lang.String getNotused();

    /**
     * 
     */
    public void setNotused(java.lang.String notused);

    /**
     * 
     */
    public int getUnusedNumber();

    /**
     * 
     */
    public void setUnusedNumber(int unusedNumber);

}
