// license-header java merge-point
package org.andromda.cartridges.jsf.tests.hyperlinkactions;

/**
 * @see org.andromda.cartridges.jsf.tests.hyperlinkactions.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 3989053449897498548L;
    
}