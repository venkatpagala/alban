// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.jsps.cannotdefercanstop;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.jsps.cannotdefercanstop.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -3398687552016294732L;
    
    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.jsps.cannotdefercanstop.Controller#doSomething()
     */
    @Override
    public void doSomething()
    {
    }
    
}