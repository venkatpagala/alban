// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 8773418983633174841L;
    
    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.Controller#duplicateName()
     */
    @Override
    public void duplicateName()
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.Controller#duplicateName(java.lang.String diffParam)
     */
    @Override
    public void duplicateName(DuplicateNameForm form)
    {
    }
    
}