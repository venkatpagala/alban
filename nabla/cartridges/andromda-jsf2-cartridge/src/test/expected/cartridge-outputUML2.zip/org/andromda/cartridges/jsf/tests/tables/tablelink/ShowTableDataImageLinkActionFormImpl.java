// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

/**
 * 
 */
public class ShowTableDataImageLinkActionFormImpl
    implements java.io.Serializable
{
    public ShowTableDataImageLinkActionFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        final java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient javax.faces.event.FacesEvent event;

    public void setEvent(javax.faces.event.FacesEvent event)
    {
        this.event = event;
    }

    public javax.faces.event.ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof javax.faces.event.ValueChangeEvent
            ? (javax.faces.event.ValueChangeEvent)this.event : null;
    }

    public javax.faces.event.ActionEvent getActionEvent()
    {
        return this.event instanceof javax.faces.event.ActionEvent
            ? (javax.faces.event.ActionEvent)this.event : null;
    }

    private java.util.Collection tableData;

    /**
     * 
     */
    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    /**
     * Keeps track of whether or not the value of tableData has
     * be populated at least once.
     */
    private boolean tableDataSet = false;

    /**
     * Resets the value of the tableDataSet to false
     */
    public void resetTableDataSet()
    {
        this.tableDataSet = false;
    }

    /**
     * Indicates whether or not the value for tableData has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataSet()
    {
        return this.tableDataSet;
    }

    /**
     * 
     */
    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
        this.tableDataSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDataValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDataLabelList;
    public java.lang.Object[] getTableDataBackingList()
    {
        java.lang.Object[] values = this.tableDataValueList;
        java.lang.Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(java.lang.Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public java.lang.Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(java.lang.Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDataBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.tableDataValueList = null;
        this.tableDataLabelList = null;
        if (items != null)
        {
            this.tableDataValueList = new java.lang.Object[items.size()];
            this.tableDataLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.tableDataValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.tableDataLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.tableDataLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    private java.util.Collection tableDataBackingValue;

    public void setTableDataBackingValue(java.util.Collection tableDataBackingValue)
    {
        this.tableDataBackingValue = tableDataBackingValue;
    }

    public java.util.Collection getTableDataBackingValue()
    {
        return this.tableDataBackingValue;
    }


    private java.lang.String[] multiboxThing;

    /**
     * 
     */
    public java.lang.String[] getMultiboxThing()
    {
        return this.multiboxThing;
    }

    /**
     * Keeps track of whether or not the value of multiboxThing has
     * be populated at least once.
     */
    private boolean multiboxThingSet = false;

    /**
     * Resets the value of the multiboxThingSet to false
     */
    public void resetMultiboxThingSet()
    {
        this.multiboxThingSet = false;
    }

    /**
     * Indicates whether or not the value for multiboxThing has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMultiboxThingSet()
    {
        return this.multiboxThingSet;
    }

    /**
     * 
     */
    public void setMultiboxThing(java.lang.String[] multiboxThing)
    {
        this.multiboxThing = multiboxThing;
        this.multiboxThingSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] multiboxThingValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] multiboxThingLabelList;
    public java.lang.Object[] getMultiboxThingBackingList()
    {
        java.lang.Object[] values = this.multiboxThingValueList;
        java.lang.Object[] labels = this.multiboxThingLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getMultiboxThingValueList()
    {
        return this.multiboxThingValueList;
    }

    public void setMultiboxThingValueList(java.lang.Object[] multiboxThingValueList)
    {
        this.multiboxThingValueList = multiboxThingValueList;
    }

    public java.lang.Object[] getMultiboxThingLabelList()
    {
        return this.multiboxThingLabelList;
    }

    public void setMultiboxThingLabelList(java.lang.Object[] multiboxThingLabelList)
    {
        this.multiboxThingLabelList = multiboxThingLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setMultiboxThingBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.multiboxThingValueList = null;
        this.multiboxThingLabelList = null;
        if (items != null)
        {
            this.multiboxThingValueList = new java.lang.Object[items.size()];
            this.multiboxThingLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.multiboxThingValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.multiboxThingLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.multiboxThingLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    private java.lang.String[] multiboxThingBackingValue;

    public void setMultiboxThingBackingValue(java.lang.String[] multiboxThingBackingValue)
    {
        this.multiboxThingBackingValue = multiboxThingBackingValue;
    }

    public java.lang.String[] getMultiboxThingBackingValue()
    {
        return this.multiboxThingBackingValue;
    }


    private java.util.Collection tableDataDefaultExportTypes;

    /**
     * 
     */
    public java.util.Collection getTableDataDefaultExportTypes()
    {
        return this.tableDataDefaultExportTypes;
    }

    /**
     * Keeps track of whether or not the value of tableDataDefaultExportTypes has
     * be populated at least once.
     */
    private boolean tableDataDefaultExportTypesSet = false;

    /**
     * Resets the value of the tableDataDefaultExportTypesSet to false
     */
    public void resetTableDataDefaultExportTypesSet()
    {
        this.tableDataDefaultExportTypesSet = false;
    }

    /**
     * Indicates whether or not the value for tableDataDefaultExportTypes has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataDefaultExportTypesSet()
    {
        return this.tableDataDefaultExportTypesSet;
    }

    /**
     * 
     */
    public void setTableDataDefaultExportTypes(java.util.Collection tableDataDefaultExportTypes)
    {
        this.tableDataDefaultExportTypes = tableDataDefaultExportTypes;
        this.tableDataDefaultExportTypesSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDataDefaultExportTypesValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDataDefaultExportTypesLabelList;
    public java.lang.Object[] getTableDataDefaultExportTypesBackingList()
    {
        java.lang.Object[] values = this.tableDataDefaultExportTypesValueList;
        java.lang.Object[] labels = this.tableDataDefaultExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getTableDataDefaultExportTypesValueList()
    {
        return this.tableDataDefaultExportTypesValueList;
    }

    public void setTableDataDefaultExportTypesValueList(java.lang.Object[] tableDataDefaultExportTypesValueList)
    {
        this.tableDataDefaultExportTypesValueList = tableDataDefaultExportTypesValueList;
    }

    public java.lang.Object[] getTableDataDefaultExportTypesLabelList()
    {
        return this.tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesLabelList(java.lang.Object[] tableDataDefaultExportTypesLabelList)
    {
        this.tableDataDefaultExportTypesLabelList = tableDataDefaultExportTypesLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDataDefaultExportTypesBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.tableDataDefaultExportTypesValueList = null;
        this.tableDataDefaultExportTypesLabelList = null;
        if (items != null)
        {
            this.tableDataDefaultExportTypesValueList = new java.lang.Object[items.size()];
            this.tableDataDefaultExportTypesLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.tableDataDefaultExportTypesValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.tableDataDefaultExportTypesLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.tableDataDefaultExportTypesLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    private java.util.Collection tableDataDefaultExportTypesBackingValue;

    public void setTableDataDefaultExportTypesBackingValue(java.util.Collection tableDataDefaultExportTypesBackingValue)
    {
        this.tableDataDefaultExportTypesBackingValue = tableDataDefaultExportTypesBackingValue;
    }

    public java.util.Collection getTableDataDefaultExportTypesBackingValue()
    {
        return this.tableDataDefaultExportTypesBackingValue;
    }


    private java.util.Collection tableDataNoExportTypes;

    /**
     * 
     */
    public java.util.Collection getTableDataNoExportTypes()
    {
        return this.tableDataNoExportTypes;
    }

    /**
     * Keeps track of whether or not the value of tableDataNoExportTypes has
     * be populated at least once.
     */
    private boolean tableDataNoExportTypesSet = false;

    /**
     * Resets the value of the tableDataNoExportTypesSet to false
     */
    public void resetTableDataNoExportTypesSet()
    {
        this.tableDataNoExportTypesSet = false;
    }

    /**
     * Indicates whether or not the value for tableDataNoExportTypes has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataNoExportTypesSet()
    {
        return this.tableDataNoExportTypesSet;
    }

    /**
     * 
     */
    public void setTableDataNoExportTypes(java.util.Collection tableDataNoExportTypes)
    {
        this.tableDataNoExportTypes = tableDataNoExportTypes;
        this.tableDataNoExportTypesSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDataNoExportTypesValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDataNoExportTypesLabelList;
    public java.lang.Object[] getTableDataNoExportTypesBackingList()
    {
        java.lang.Object[] values = this.tableDataNoExportTypesValueList;
        java.lang.Object[] labels = this.tableDataNoExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getTableDataNoExportTypesValueList()
    {
        return this.tableDataNoExportTypesValueList;
    }

    public void setTableDataNoExportTypesValueList(java.lang.Object[] tableDataNoExportTypesValueList)
    {
        this.tableDataNoExportTypesValueList = tableDataNoExportTypesValueList;
    }

    public java.lang.Object[] getTableDataNoExportTypesLabelList()
    {
        return this.tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesLabelList(java.lang.Object[] tableDataNoExportTypesLabelList)
    {
        this.tableDataNoExportTypesLabelList = tableDataNoExportTypesLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDataNoExportTypesBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.tableDataNoExportTypesValueList = null;
        this.tableDataNoExportTypesLabelList = null;
        if (items != null)
        {
            this.tableDataNoExportTypesValueList = new java.lang.Object[items.size()];
            this.tableDataNoExportTypesLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.tableDataNoExportTypesValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.tableDataNoExportTypesLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.tableDataNoExportTypesLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    private java.util.Collection tableDataNoExportTypesBackingValue;

    public void setTableDataNoExportTypesBackingValue(java.util.Collection tableDataNoExportTypesBackingValue)
    {
        this.tableDataNoExportTypesBackingValue = tableDataNoExportTypesBackingValue;
    }

    public java.util.Collection getTableDataNoExportTypesBackingValue()
    {
        return this.tableDataNoExportTypesBackingValue;
    }


    private java.util.Collection tableDataNotSortable;

    /**
     * 
     */
    public java.util.Collection getTableDataNotSortable()
    {
        return this.tableDataNotSortable;
    }

    /**
     * Keeps track of whether or not the value of tableDataNotSortable has
     * be populated at least once.
     */
    private boolean tableDataNotSortableSet = false;

    /**
     * Resets the value of the tableDataNotSortableSet to false
     */
    public void resetTableDataNotSortableSet()
    {
        this.tableDataNotSortableSet = false;
    }

    /**
     * Indicates whether or not the value for tableDataNotSortable has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataNotSortableSet()
    {
        return this.tableDataNotSortableSet;
    }

    /**
     * 
     */
    public void setTableDataNotSortable(java.util.Collection tableDataNotSortable)
    {
        this.tableDataNotSortable = tableDataNotSortable;
        this.tableDataNotSortableSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDataNotSortableValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDataNotSortableLabelList;
    public java.lang.Object[] getTableDataNotSortableBackingList()
    {
        java.lang.Object[] values = this.tableDataNotSortableValueList;
        java.lang.Object[] labels = this.tableDataNotSortableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getTableDataNotSortableValueList()
    {
        return this.tableDataNotSortableValueList;
    }

    public void setTableDataNotSortableValueList(java.lang.Object[] tableDataNotSortableValueList)
    {
        this.tableDataNotSortableValueList = tableDataNotSortableValueList;
    }

    public java.lang.Object[] getTableDataNotSortableLabelList()
    {
        return this.tableDataNotSortableLabelList;
    }

    public void setTableDataNotSortableLabelList(java.lang.Object[] tableDataNotSortableLabelList)
    {
        this.tableDataNotSortableLabelList = tableDataNotSortableLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDataNotSortableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.tableDataNotSortableValueList = null;
        this.tableDataNotSortableLabelList = null;
        if (items != null)
        {
            this.tableDataNotSortableValueList = new java.lang.Object[items.size()];
            this.tableDataNotSortableLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.tableDataNotSortableValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.tableDataNotSortableLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.tableDataNotSortableLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    private java.util.Collection tableDataNotSortableBackingValue;

    public void setTableDataNotSortableBackingValue(java.util.Collection tableDataNotSortableBackingValue)
    {
        this.tableDataNotSortableBackingValue = tableDataNotSortableBackingValue;
    }

    public java.util.Collection getTableDataNotSortableBackingValue()
    {
        return this.tableDataNotSortableBackingValue;
    }


    private int first;

    /**
     * 
     */
    public int getFirst()
    {
        return this.first;
    }

    /**
     * Keeps track of whether or not the value of first has
     * be populated at least once.
     */
    private boolean firstSet = false;

    /**
     * Resets the value of the firstSet to false
     */
    public void resetFirstSet()
    {
        this.firstSet = false;
    }

    /**
     * Indicates whether or not the value for first has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFirstSet()
    {
        return this.firstSet;
    }

    /**
     * 
     */
    public void setFirst(int first)
    {
        this.first = first;
        this.firstSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] firstValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] firstLabelList;
    public java.lang.Object[] getFirstBackingList()
    {
        java.lang.Object[] values = this.firstValueList;
        java.lang.Object[] labels = this.firstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getFirstValueList()
    {
        return this.firstValueList;
    }

    public void setFirstValueList(java.lang.Object[] firstValueList)
    {
        this.firstValueList = firstValueList;
    }

    public java.lang.Object[] getFirstLabelList()
    {
        return this.firstLabelList;
    }

    public void setFirstLabelList(java.lang.Object[] firstLabelList)
    {
        this.firstLabelList = firstLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFirstBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.firstValueList = null;
        this.firstLabelList = null;
        if (items != null)
        {
            this.firstValueList = new java.lang.Object[items.size()];
            this.firstLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.firstValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.firstLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.firstLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String third;

    /**
     * 
     */
    public java.lang.String getThird()
    {
        return this.third;
    }

    /**
     * Keeps track of whether or not the value of third has
     * be populated at least once.
     */
    private boolean thirdSet = false;

    /**
     * Resets the value of the thirdSet to false
     */
    public void resetThirdSet()
    {
        this.thirdSet = false;
    }

    /**
     * Indicates whether or not the value for third has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThirdSet()
    {
        return this.thirdSet;
    }

    /**
     * 
     */
    public void setThird(java.lang.String third)
    {
        this.third = third;
        this.thirdSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] thirdValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] thirdLabelList;
    public java.lang.Object[] getThirdBackingList()
    {
        java.lang.Object[] values = this.thirdValueList;
        java.lang.Object[] labels = this.thirdLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getThirdValueList()
    {
        return this.thirdValueList;
    }

    public void setThirdValueList(java.lang.Object[] thirdValueList)
    {
        this.thirdValueList = thirdValueList;
    }

    public java.lang.Object[] getThirdLabelList()
    {
        return this.thirdLabelList;
    }

    public void setThirdLabelList(java.lang.Object[] thirdLabelList)
    {
        this.thirdLabelList = thirdLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setThirdBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.thirdValueList = null;
        this.thirdLabelList = null;
        if (items != null)
        {
            this.thirdValueList = new java.lang.Object[items.size()];
            this.thirdLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.thirdValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.thirdLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.thirdLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String two;

    /**
     * 
     */
    public java.lang.String getTwo()
    {
        return this.two;
    }

    /**
     * Keeps track of whether or not the value of two has
     * be populated at least once.
     */
    private boolean twoSet = false;

    /**
     * Resets the value of the twoSet to false
     */
    public void resetTwoSet()
    {
        this.twoSet = false;
    }

    /**
     * Indicates whether or not the value for two has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTwoSet()
    {
        return this.twoSet;
    }

    /**
     * 
     */
    public void setTwo(java.lang.String two)
    {
        this.two = two;
        this.twoSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] twoValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] twoLabelList;
    public java.lang.Object[] getTwoBackingList()
    {
        java.lang.Object[] values = this.twoValueList;
        java.lang.Object[] labels = this.twoLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getTwoValueList()
    {
        return this.twoValueList;
    }

    public void setTwoValueList(java.lang.Object[] twoValueList)
    {
        this.twoValueList = twoValueList;
    }

    public java.lang.Object[] getTwoLabelList()
    {
        return this.twoLabelList;
    }

    public void setTwoLabelList(java.lang.Object[] twoLabelList)
    {
        this.twoLabelList = twoLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTwoBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.twoValueList = null;
        this.twoLabelList = null;
        if (items != null)
        {
            this.twoValueList = new java.lang.Object[items.size()];
            this.twoLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.twoValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.twoLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.twoLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String second;

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }

    /**
     * Keeps track of whether or not the value of second has
     * be populated at least once.
     */
    private boolean secondSet = false;

    /**
     * Resets the value of the secondSet to false
     */
    public void resetSecondSet()
    {
        this.secondSet = false;
    }

    /**
     * Indicates whether or not the value for second has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSecondSet()
    {
        return this.secondSet;
    }

    /**
     * 
     */
    public void setSecond(java.lang.String second)
    {
        this.second = second;
        this.secondSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] secondValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] secondLabelList;
    public java.lang.Object[] getSecondBackingList()
    {
        java.lang.Object[] values = this.secondValueList;
        java.lang.Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(java.lang.Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public java.lang.Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(java.lang.Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setSecondBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.secondValueList = null;
        this.secondLabelList = null;
        if (items != null)
        {
            this.secondValueList = new java.lang.Object[items.size()];
            this.secondLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.secondValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.secondLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.secondLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private int formParam1;

    /**
     * 
     */
    public int getFormParam1()
    {
        return this.formParam1;
    }

    /**
     * Keeps track of whether or not the value of formParam1 has
     * be populated at least once.
     */
    private boolean formParam1Set = false;

    /**
     * Resets the value of the formParam1Set to false
     */
    public void resetFormParam1Set()
    {
        this.formParam1Set = false;
    }

    /**
     * Indicates whether or not the value for formParam1 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFormParam1Set()
    {
        return this.formParam1Set;
    }

    /**
     * 
     */
    public void setFormParam1(int formParam1)
    {
        this.formParam1 = formParam1;
        this.formParam1Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] formParam1ValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] formParam1LabelList;
    public java.lang.Object[] getFormParam1BackingList()
    {
        java.lang.Object[] values = this.formParam1ValueList;
        java.lang.Object[] labels = this.formParam1LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getFormParam1ValueList()
    {
        return this.formParam1ValueList;
    }

    public void setFormParam1ValueList(java.lang.Object[] formParam1ValueList)
    {
        this.formParam1ValueList = formParam1ValueList;
    }

    public java.lang.Object[] getFormParam1LabelList()
    {
        return this.formParam1LabelList;
    }

    public void setFormParam1LabelList(java.lang.Object[] formParam1LabelList)
    {
        this.formParam1LabelList = formParam1LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFormParam1BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.formParam1ValueList = null;
        this.formParam1LabelList = null;
        if (items != null)
        {
            this.formParam1ValueList = new java.lang.Object[items.size()];
            this.formParam1LabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.formParam1ValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.formParam1LabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.formParam1LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String formParam2;

    /**
     * 
     */
    public java.lang.String getFormParam2()
    {
        return this.formParam2;
    }

    /**
     * Keeps track of whether or not the value of formParam2 has
     * be populated at least once.
     */
    private boolean formParam2Set = false;

    /**
     * Resets the value of the formParam2Set to false
     */
    public void resetFormParam2Set()
    {
        this.formParam2Set = false;
    }

    /**
     * Indicates whether or not the value for formParam2 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFormParam2Set()
    {
        return this.formParam2Set;
    }

    /**
     * 
     */
    public void setFormParam2(java.lang.String formParam2)
    {
        this.formParam2 = formParam2;
        this.formParam2Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] formParam2ValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] formParam2LabelList;
    public java.lang.Object[] getFormParam2BackingList()
    {
        java.lang.Object[] values = this.formParam2ValueList;
        java.lang.Object[] labels = this.formParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getFormParam2ValueList()
    {
        return this.formParam2ValueList;
    }

    public void setFormParam2ValueList(java.lang.Object[] formParam2ValueList)
    {
        this.formParam2ValueList = formParam2ValueList;
    }

    public java.lang.Object[] getFormParam2LabelList()
    {
        return this.formParam2LabelList;
    }

    public void setFormParam2LabelList(java.lang.Object[] formParam2LabelList)
    {
        this.formParam2LabelList = formParam2LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFormParam2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.formParam2ValueList = null;
        this.formParam2LabelList = null;
        if (items != null)
        {
            this.formParam2ValueList = new java.lang.Object[items.size()];
            this.formParam2LabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.formParam2ValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.formParam2LabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.formParam2LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String parameterWithDefaultValue = "aDefaultValue";

    /**
     * 
     */
    public java.lang.String getParameterWithDefaultValue()
    {
        return this.parameterWithDefaultValue;
    }

    /**
     * Keeps track of whether or not the value of parameterWithDefaultValue has
     * be populated at least once.
     */
    private boolean parameterWithDefaultValueSet = false;

    /**
     * Resets the value of the parameterWithDefaultValueSet to false
     */
    public void resetParameterWithDefaultValueSet()
    {
        this.parameterWithDefaultValueSet = false;
    }

    /**
     * Indicates whether or not the value for parameterWithDefaultValue has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParameterWithDefaultValueSet()
    {
        return this.parameterWithDefaultValueSet;
    }

    /**
     * 
     */
    public void setParameterWithDefaultValue(java.lang.String parameterWithDefaultValue)
    {
        this.parameterWithDefaultValue = parameterWithDefaultValue;
        this.parameterWithDefaultValueSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] parameterWithDefaultValueValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] parameterWithDefaultValueLabelList;
    public java.lang.Object[] getParameterWithDefaultValueBackingList()
    {
        java.lang.Object[] values = this.parameterWithDefaultValueValueList;
        java.lang.Object[] labels = this.parameterWithDefaultValueLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getParameterWithDefaultValueValueList()
    {
        return this.parameterWithDefaultValueValueList;
    }

    public void setParameterWithDefaultValueValueList(java.lang.Object[] parameterWithDefaultValueValueList)
    {
        this.parameterWithDefaultValueValueList = parameterWithDefaultValueValueList;
    }

    public java.lang.Object[] getParameterWithDefaultValueLabelList()
    {
        return this.parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueLabelList(java.lang.Object[] parameterWithDefaultValueLabelList)
    {
        this.parameterWithDefaultValueLabelList = parameterWithDefaultValueLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setParameterWithDefaultValueBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.parameterWithDefaultValueValueList = null;
        this.parameterWithDefaultValueLabelList = null;
        if (items != null)
        {
            this.parameterWithDefaultValueValueList = new java.lang.Object[items.size()];
            this.parameterWithDefaultValueLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.parameterWithDefaultValueValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.parameterWithDefaultValueLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.parameterWithDefaultValueLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String fourth;

    /**
     * 
     */
    public java.lang.String getFourth()
    {
        return this.fourth;
    }

    /**
     * Keeps track of whether or not the value of fourth has
     * be populated at least once.
     */
    private boolean fourthSet = false;

    /**
     * Resets the value of the fourthSet to false
     */
    public void resetFourthSet()
    {
        this.fourthSet = false;
    }

    /**
     * Indicates whether or not the value for fourth has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFourthSet()
    {
        return this.fourthSet;
    }

    /**
     * 
     */
    public void setFourth(java.lang.String fourth)
    {
        this.fourth = fourth;
        this.fourthSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] fourthValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] fourthLabelList;
    public java.lang.Object[] getFourthBackingList()
    {
        java.lang.Object[] values = this.fourthValueList;
        java.lang.Object[] labels = this.fourthLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getFourthValueList()
    {
        return this.fourthValueList;
    }

    public void setFourthValueList(java.lang.Object[] fourthValueList)
    {
        this.fourthValueList = fourthValueList;
    }

    public java.lang.Object[] getFourthLabelList()
    {
        return this.fourthLabelList;
    }

    public void setFourthLabelList(java.lang.Object[] fourthLabelList)
    {
        this.fourthLabelList = fourthLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFourthBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.fourthValueList = null;
        this.fourthLabelList = null;
        if (items != null)
        {
            this.fourthValueList = new java.lang.Object[items.size()];
            this.fourthLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.fourthValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.fourthLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.fourthLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String thisOneShouldbeNamedFirst;

    /**
     * 
     */
    public java.lang.String getThisOneShouldbeNamedFirst()
    {
        return this.thisOneShouldbeNamedFirst;
    }

    /**
     * Keeps track of whether or not the value of thisOneShouldbeNamedFirst has
     * be populated at least once.
     */
    private boolean thisOneShouldbeNamedFirstSet = false;

    /**
     * Resets the value of the thisOneShouldbeNamedFirstSet to false
     */
    public void resetThisOneShouldbeNamedFirstSet()
    {
        this.thisOneShouldbeNamedFirstSet = false;
    }

    /**
     * Indicates whether or not the value for thisOneShouldbeNamedFirst has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThisOneShouldbeNamedFirstSet()
    {
        return this.thisOneShouldbeNamedFirstSet;
    }

    /**
     * 
     */
    public void setThisOneShouldbeNamedFirst(java.lang.String thisOneShouldbeNamedFirst)
    {
        this.thisOneShouldbeNamedFirst = thisOneShouldbeNamedFirst;
        this.thisOneShouldbeNamedFirstSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] thisOneShouldbeNamedFirstValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] thisOneShouldbeNamedFirstLabelList;
    public java.lang.Object[] getThisOneShouldbeNamedFirstBackingList()
    {
        java.lang.Object[] values = this.thisOneShouldbeNamedFirstValueList;
        java.lang.Object[] labels = this.thisOneShouldbeNamedFirstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getThisOneShouldbeNamedFirstValueList()
    {
        return this.thisOneShouldbeNamedFirstValueList;
    }

    public void setThisOneShouldbeNamedFirstValueList(java.lang.Object[] thisOneShouldbeNamedFirstValueList)
    {
        this.thisOneShouldbeNamedFirstValueList = thisOneShouldbeNamedFirstValueList;
    }

    public java.lang.Object[] getThisOneShouldbeNamedFirstLabelList()
    {
        return this.thisOneShouldbeNamedFirstLabelList;
    }

    public void setThisOneShouldbeNamedFirstLabelList(java.lang.Object[] thisOneShouldbeNamedFirstLabelList)
    {
        this.thisOneShouldbeNamedFirstLabelList = thisOneShouldbeNamedFirstLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setThisOneShouldbeNamedFirstBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.thisOneShouldbeNamedFirstValueList = null;
        this.thisOneShouldbeNamedFirstLabelList = null;
        if (items != null)
        {
            this.thisOneShouldbeNamedFirstValueList = new java.lang.Object[items.size()];
            this.thisOneShouldbeNamedFirstLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.thisOneShouldbeNamedFirstValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.thisOneShouldbeNamedFirstLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.thisOneShouldbeNamedFirstLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String unknownParameter;

    /**
     * 
     */
    public java.lang.String getUnknownParameter()
    {
        return this.unknownParameter;
    }

    /**
     * Keeps track of whether or not the value of unknownParameter has
     * be populated at least once.
     */
    private boolean unknownParameterSet = false;

    /**
     * Resets the value of the unknownParameterSet to false
     */
    public void resetUnknownParameterSet()
    {
        this.unknownParameterSet = false;
    }

    /**
     * Indicates whether or not the value for unknownParameter has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isUnknownParameterSet()
    {
        return this.unknownParameterSet;
    }

    /**
     * 
     */
    public void setUnknownParameter(java.lang.String unknownParameter)
    {
        this.unknownParameter = unknownParameter;
        this.unknownParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] unknownParameterValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] unknownParameterLabelList;
    public java.lang.Object[] getUnknownParameterBackingList()
    {
        java.lang.Object[] values = this.unknownParameterValueList;
        java.lang.Object[] labels = this.unknownParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getUnknownParameterValueList()
    {
        return this.unknownParameterValueList;
    }

    public void setUnknownParameterValueList(java.lang.Object[] unknownParameterValueList)
    {
        this.unknownParameterValueList = unknownParameterValueList;
    }

    public java.lang.Object[] getUnknownParameterLabelList()
    {
        return this.unknownParameterLabelList;
    }

    public void setUnknownParameterLabelList(java.lang.Object[] unknownParameterLabelList)
    {
        this.unknownParameterLabelList = unknownParameterLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setUnknownParameterBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.unknownParameterValueList = null;
        this.unknownParameterLabelList = null;
        if (items != null)
        {
            this.unknownParameterValueList = new java.lang.Object[items.size()];
            this.unknownParameterLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.unknownParameterValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.unknownParameterLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.unknownParameterLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String thisParameterNameDoesNotExistAsTableColumn;

    /**
     * 
     */
    public java.lang.String getThisParameterNameDoesNotExistAsTableColumn()
    {
        return this.thisParameterNameDoesNotExistAsTableColumn;
    }

    /**
     * Keeps track of whether or not the value of thisParameterNameDoesNotExistAsTableColumn has
     * be populated at least once.
     */
    private boolean thisParameterNameDoesNotExistAsTableColumnSet = false;

    /**
     * Resets the value of the thisParameterNameDoesNotExistAsTableColumnSet to false
     */
    public void resetThisParameterNameDoesNotExistAsTableColumnSet()
    {
        this.thisParameterNameDoesNotExistAsTableColumnSet = false;
    }

    /**
     * Indicates whether or not the value for thisParameterNameDoesNotExistAsTableColumn has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThisParameterNameDoesNotExistAsTableColumnSet()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnSet;
    }

    /**
     * 
     */
    public void setThisParameterNameDoesNotExistAsTableColumn(java.lang.String thisParameterNameDoesNotExistAsTableColumn)
    {
        this.thisParameterNameDoesNotExistAsTableColumn = thisParameterNameDoesNotExistAsTableColumn;
        this.thisParameterNameDoesNotExistAsTableColumnSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnLabelList;
    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnBackingList()
    {
        java.lang.Object[] values = this.thisParameterNameDoesNotExistAsTableColumnValueList;
        java.lang.Object[] labels = this.thisParameterNameDoesNotExistAsTableColumnLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(
                values[ctr] != null ? values[ctr] : "", labels[ctr] != null ? java.lang.String.valueOf(labels[ctr]) : "");
        }
        return backingList;
    }

    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnValueList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnValueList(java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnValueList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnValueList = thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnLabelList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnLabelList(java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnLabelList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.thisParameterNameDoesNotExistAsTableColumnValueList = null;
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = null;
        if (items != null)
        {
            this.thisParameterNameDoesNotExistAsTableColumnValueList = new java.lang.Object[items.size()];
            this.thisParameterNameDoesNotExistAsTableColumnLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    if (item != null)
                    {
                        this.thisParameterNameDoesNotExistAsTableColumnValueList[ctr] = valueProperty == null ? item :
                            org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                        if (labelProperties == null)
                        {
                            this.thisParameterNameDoesNotExistAsTableColumnLabelList[ctr] = item;
                        }
                        else
                        {
                            final StringBuffer labelText = new StringBuffer();
				            int ctr2 = 0;
				            do
				            {
				                if (!labelDelimiters.isEmpty())
				                {
				                    labelText.append(labelDelimiters.get(ctr2));
				                }
				                String property = null;
				                if (ctr2 < labelProperties.size())
				                {
				                    property = labelProperties.get(ctr2);
				                }
                                if (property != null && property.length() > 0)
                                {
                                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                    {
                                        Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                        if (value != null)
                                        {
                                            if (value instanceof String)
                                            {
                                                if (((String)value).trim().length() == 0)
                                                {
                                                    value = null;
                                                }
                                            }
                                            if (value != null)
                                            {
                                                labelText.append(value);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        labelText.append(property);
                                    }
                                }
				                ctr2++;
				            }
				            while (ctr2 < labelDelimiters.size());
                            this.thisParameterNameDoesNotExistAsTableColumnLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                        }
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetTableDataSet();
         this.resetMultiboxThingSet();
         this.resetTableDataDefaultExportTypesSet();
         this.resetTableDataNoExportTypesSet();
         this.resetTableDataNotSortableSet();
         this.resetFirstSet();
         this.resetThirdSet();
         this.resetTwoSet();
         this.resetSecondSet();
         this.resetFormParam1Set();
         this.resetFormParam2Set();
         this.resetParameterWithDefaultValueSet();
         this.resetFourthSet();
         this.resetThisOneShouldbeNamedFirstSet();
         this.resetUnknownParameterSet();
         this.resetThisParameterNameDoesNotExistAsTableColumnSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map<java.lang.String, java.text.DateFormat> dateTimeFormatters =
        new java.util.HashMap<java.lang.String, java.text.DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map<java.lang.String, java.text.DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient java.util.Map<java.lang.String, javax.faces.application.FacesMessage> jsfMessages =
        new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection<javax.faces.application.FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection<javax.faces.application.FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public javax.faces.application.FacesMessage.Severity getMaximumMessageSeverity()
    {
        javax.faces.application.FacesMessage.Severity maxSeverity = null;
        for (final javax.faces.application.FacesMessage message : this.getJsfMessages())
        {
            final javax.faces.application.FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -8781870034843984613L;
}
