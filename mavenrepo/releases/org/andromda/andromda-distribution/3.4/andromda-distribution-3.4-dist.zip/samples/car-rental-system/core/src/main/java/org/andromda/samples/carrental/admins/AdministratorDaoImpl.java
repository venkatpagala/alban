// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.admins;

/**
 * @see org.andromda.samples.carrental.admins.Administrator
 */
public class AdministratorDaoImpl
    extends AdministratorDaoBase
{
}
