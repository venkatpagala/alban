// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.inventory;

import java.util.Collection;

/**
 * @see org.andromda.samples.carrental.inventory.InventoryService
 */
public class InventoryServiceImpl
    extends InventoryServiceBase
{
    /**
     * @see org.andromda.samples.carrental.inventory.InventoryService#createCarType(CarTypeData)
     */
    protected String handleCreateCarType(CarTypeData typeData)
        throws Exception
    {
        //@todo implement protected String handleCreateCarType(CarTypeData typeData)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.inventory.InventoryService#createCar(CarData, String)
     */
    protected String handleCreateCar(CarData carData, String carTypeId)
        throws Exception
    {
        //@todo implement protected String handleCreateCar(CarData carData, String carTypeId)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.inventory.InventoryService#searchCarByComfortClass(String)
     */
    protected Collection handleSearchCarByComfortClass(String comfortClass)
        throws Exception
    {
        //@todo implement protected Collection handleSearchCarByComfortClass(String comfortClass)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.inventory.InventoryService#searchAllCarTypes()
     */
    protected Collection handleSearchAllCarTypes()
        throws Exception
    {
        //@todo implement protected Collection handleSearchAllCarTypes()
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.inventory.InventoryService#searchAllCars()
     */
    protected Collection handleSearchAllCars()
        throws Exception
    {
        //@todo implement protected Collection handleSearchAllCars()
        return null;
    }
}
