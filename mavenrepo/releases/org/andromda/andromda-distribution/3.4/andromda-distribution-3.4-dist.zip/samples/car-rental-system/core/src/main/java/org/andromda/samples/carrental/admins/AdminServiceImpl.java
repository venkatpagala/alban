// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.carrental.admins;

/**
 * @see org.andromda.samples.carrental.admins.AdminService
 */
public class AdminServiceImpl
    extends AdminServiceBase
{
    /**
     * @see org.andromda.samples.carrental.admins.AdminService#authenticateAsAdministrator(String, String, String)
     */
    protected String handleAuthenticateAsAdministrator(String name, String accountNo, String password)
        throws Exception
    {
        //@todo implement protected String handleAuthenticateAsAdministrator(String name, String accountNo, String password)
        return null;
    }

    /**
     * @see org.andromda.samples.carrental.admins.AdminService#createAdministrator(String, String, String)
     */
    protected String handleCreateAdministrator(String name, String accountNo, String password)
        throws Exception
    {
        //@todo implement protected String handleCreateAdministrator(String name, String accountNo, String password)
        return null;
    }
}
