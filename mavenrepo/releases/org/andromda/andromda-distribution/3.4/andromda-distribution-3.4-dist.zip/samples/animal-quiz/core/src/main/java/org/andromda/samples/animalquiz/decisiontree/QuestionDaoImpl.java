// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.samples.animalquiz.decisiontree;

/**
 * @see org.andromda.samples.animalquiz.decisiontree.Question
 */
public class QuestionDaoImpl
    extends QuestionDaoBase
{
}