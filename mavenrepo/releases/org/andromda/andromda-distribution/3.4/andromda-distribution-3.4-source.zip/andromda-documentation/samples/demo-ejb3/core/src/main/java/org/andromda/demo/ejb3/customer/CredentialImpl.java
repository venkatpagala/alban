// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.demo.ejb3.customer;

/**
 * @see org.andromda.demo.ejb3.customer.Credential
 */
public class CredentialImpl
    extends org.andromda.demo.ejb3.customer.Credential
    implements java.io.Serializable
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 9121678933567284167L;
}