// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.demo.ejb3.animal;

/**
 * @see org.andromda.demo.ejb3.animal.Animal
 */
public class AnimalDaoImpl
    extends org.andromda.demo.ejb3.animal.AnimalDaoBase
{
}