delete from TIME_ALLOCATION;
delete from TIMECARD;